﻿// Кнопка «Смотреть демо»: проходит сквозной сценарий ТЗ (шаги 1–8) через настоящий интерфейс —
// те же кнопки, формы и хранилище, что у пользователя. Остановить можно в любой момент.
window.Demo = (function () {
  let running = false, stopFlag = false;
  const q = s => document.querySelector(s);
  const tr = window.I18N.t;

  function wait(ms) {
    return new Promise((resolve, reject) => setTimeout(() => (stopFlag ? reject(new Error('stop')) : resolve()), ms));
  }
  async function waitFor(check, timeout) {
    const until = Date.now() + (timeout || 15000);
    while (Date.now() < until) {
      const r = typeof check === 'string' ? q(check) : check();
      if (r) return r;
      await wait(120);
    }
    throw new Error('timeout: ' + check);
  }
  function fire(el, type) { el.dispatchEvent(new Event(type, { bubbles: true })); }
  async function type(el, text) {
    el.scrollIntoView({ block: 'center', behavior: 'smooth' });
    el.focus();
    el.value = '';
    for (let i = 0; i < text.length; i += 3) {
      el.value = text.slice(0, i + 3);
      fire(el, 'input');
      await wait(14);
    }
    fire(el, 'change');
  }
  function click(sel) {
    const el = typeof sel === 'string' ? q(sel) : sel;
    if (!el) throw new Error('no element: ' + sel);
    el.scrollIntoView({ block: 'center', behavior: 'smooth' });
    el.click();
  }
  async function go(hash, ready) {
    if (location.hash === hash) window.App.render();
    else location.hash = hash;
    await wait(800);
    if (ready) await waitFor(ready);
  }
  function setRole(role, who) {
    const s = window.Store.get();
    s.role = role;
    if (role === 'business') s.currentCompany = who; else s.currentTeamId = who;
    window.Store.save();
  }

  // Подпись шага: ключ словаря I18N (текст на текущем языке интерфейса).
  function bar(step, key, arg) {
    let el = q('#demo-bar');
    if (!el) {
      el = document.createElement('div');
      el.id = 'demo-bar';
      el.innerHTML = '<span class="mono step"></span><span class="txt"></span><button class="btn ghost small"></button>';
      el.querySelector('button').onclick = () => { stopFlag = true; };
      document.body.appendChild(el);
    }
    el.querySelector('button').textContent = tr('demo.stop');
    el.querySelector('.step').textContent = step ? tr('demo.step', step) : tr('demo.label');
    el.querySelector('.txt').textContent = tr(key, arg);
  }

  async function run() {
    if (running) return;
    running = true; stopFlag = false;
    const D = window.SEED.demo;
    try {
      // 1. Черновик
      setRole('business', D.company);
      bar(1, 'demo.1');
      await go('#/forge', '#w-draft, [data-action="restart"]');
      if (q('[data-action="restart"]')) { click('[data-action="restart"]'); await waitFor('#w-draft'); }
      q('#w-company').value = D.company;
      q('#w-industry').value = D.industry;
      await type(q('#w-draft'), D.draft);
      await wait(900);

      // 2. Уточнение
      bar(2, 'demo.2');
      click('[data-action="analyze"]');
      await waitFor('[data-q]');
      await wait(1500);

      // 3–4. Ответы → рейтинг растёт
      bar(3, 'demo.3');
      const fields = [...document.querySelectorAll('.qcard')].map((c, i) => ({ i, field: c.dataset.field }));
      for (const { i, field } of fields) {
        if (!D.answers[field]) continue;           // один вопрос намеренно пропускаем
        await type(q(`[data-q="${i}"]`), D.answers[field]);
        await wait(900);
      }
      bar(3, 'demo.3b');
      await wait(1600);
      click('[data-action="build"]');
      await waitFor('[data-f="title"]');
      bar(4, 'demo.4');
      await wait(1200);
      click('[data-action="confirm"]');
      await wait(1100);
      bar(4, 'demo.4b');
      for (const [field, text] of Object.entries(D.edits)) {
        await type(q(`[data-f="${field}"]`), text);
        await wait(900);
      }
      click('[data-action="confirm"]');
      await wait(1300);

      // 5. Публикация
      bar(5, 'demo.5');
      click('[data-action="publish"]');
      await waitFor(() => location.hash === '#/catalog');
      await wait(2600);
      const s = window.Store.get();
      const task = s.tasks.slice().sort((a, b) => b.createdAt - a.createdAt)[0];

      // 6. Выбор студентов
      bar(6, 'demo.6');
      setRole('team', D.team);
      await go('#/compass', '#compass');
      await wait(2400);
      bar(6, 'demo.6b');
      await go('#/task/' + task.id, '#cf-team');
      q('#cf-team').value = D.team;
      await type(q('#cf-idea'), D.contract.idea);
      await type(q('#cf-plan'), D.contract.plan);
      await type(q('#cf-weeks'), String(D.contract.weeks));
      await type(q('#cf-link'), D.contract.link);
      q('#sig').scrollIntoView({ block: 'center', behavior: 'smooth' });
      await wait(500);
      window.App.drawDemoSignature();
      await wait(900);
      click('[data-action="propose"]');
      await wait(2000);

      // 7. Выбор бизнеса
      bar(7, 'demo.7');
      setRole('business', D.company);
      await go('#/task/' + task.id, '.scrolls-panel');
      const p = s.proposals.filter(x => x.taskId === task.id).sort((a, b) => b.createdAt - a.createdAt)[0];
      click(`[data-action="unroll"][data-id="${p.id}"]`);
      await wait(1500);
      click(`[data-action="p-accept"][data-id="${p.id}"]`);
      await wait(2600);

      // 8. Результат
      bar(8, 'demo.8');
      setRole('team', D.team);
      await go('#/contracts', '.scroll');
      await wait(3200);
      bar(0, 'demo.done');
      await wait(3500);
    } catch (e) {
      if (e.message !== 'stop') { console.error(e); bar(0, 'demo.stopped', e.message); await new Promise(r => setTimeout(r, 3000)); }
    } finally {
      running = false;
      const el = q('#demo-bar');
      if (el) el.remove();
    }
  }

  return { run };
})();

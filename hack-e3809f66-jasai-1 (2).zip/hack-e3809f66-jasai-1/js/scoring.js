// Формула рейтинга готовности бизнес-задачи (0–100).
// Чистые функции без зависимостей от DOM — используются в приложении и в tests.html.
// Тексты (подписи, подсказки, вопросы) берутся из словаря I18N на текущем языке;
// признаки полноты понимают русский, казахский и английский.
window.Scoring = (function () {
  const tr = window.I18N.t;

  /** Делает текстовые свойства объекта «живыми»: при каждом чтении — перевод на текущий язык. */
  function localized(obj, prefix, props) {
    props.forEach(p => Object.defineProperty(obj, p, { get: () => tr(`${prefix}.${p}`), enumerable: true }));
    return obj;
  }
  const TEXT = ['label', 'placeholder', 'question', 'hint'];

  const FIELDS = [
    { key: 'title', weight: 0 },
    { key: 'context', weight: 10,
      strong: t => t.length >= 80 },
    { key: 'need', weight: 10,
      strong: t => t.length >= 40 && /(нуж|необходим|хоти|требует|автоматиз|сократ|повыс|сниз|улучш|созда|разработ|ускор|избав|қажет|керек|азайт|жақсарт|автоматтанд|арттыр|жаса|құр|need|want|reduce|improve|automat|increase|create|build|speed up|cut)/i.test(t) },
    { key: 'users', weight: 10,
      strong: t => /(сотрудн|клиент|менедж|пользоват|оператор|покупат|студент|учени|врач|бухгалт|водител|курьер|продав|аналит|руковод|агроном|куратор|пациент|диспетчер|регистратор|бариста|гост|пайдаланушы|қызметкер|оқушы|мұғалім|дәрігер|сатушы|жүргізуші|басшы|user|employee|staff|customer|client|manager|operator|student|teacher|courier|dispatcher|analyst|doctor|driver|\d)/i.test(t) },
    { key: 'data', weight: 20,
      // Полный балл: назван источник И указан объём/период/формат (цифра) либо описание развёрнутое.
      strong: t => /(csv|xlsx|excel|json|sql|api|выгрузк|таблиц|баз[аеыу]|лог|архив|пример|датасет|запис|строк|фото|crm|мис|1с|1c|google sheets|дерек|кесте|мұрағат|мысал|жазба|экспорт|dataset|export|table|database|log|archive|example|photo|record|spreadsheet)/i.test(t) && (/\d/.test(t) || t.length >= 60) },
    { key: 'expected_result', weight: 15,
      strong: t => t.length >= 50 && /(прототип|дашборд|бот|сервис|модел|отч[её]т|приложен|скрипт|mvp|панел|api|сайт|систем|интерфейс|алгоритм|рекомендац|таблиц|есеп|қосымша|жүйе|prototype|dashboard|bot|service|model|report|app|script|panel|website|system|interface|algorithm)/i.test(t) },
    { key: 'success_criteria', weight: 15,
      strong: t => /\d/.test(t) },
    { key: 'constraints', weight: 10,
      strong: t => /(срок|недел|месяц|дн[еяи]|до \d|python|javascript|1с|1c|доступ|nda|бюджет|технолог|облак|сервер|стек|конфиденц|мерзім|апта|қолжетім|құпия|deadline|week|month|access|budget|stack|server|cloud|confidential|\d)/i.test(t) },
    { key: 'contact', weight: 5,
      strong: t => /(@|\+?\d[\d\s()\-]{6,}|t\.me)/i.test(t) },
    { key: 'interaction_format', weight: 5,
      strong: t => /(раз в|еженедел|ежеднев|созвон|встреч|zoom|teams|meet|телеграм|telegram|чат|онлайн|офлайн|очно|консультац|апта сайын|аптасына|күн сайын|кездесу|қоңырау|кеңес|weekly|daily|call|meeting|chat|online|offline|consult)/i.test(t) },
  ].map(f => localized(f, `field.${f.key}`, f.key === 'title' ? ['label', 'placeholder'] : TEXT));

  const SCORED = FIELDS.filter(f => f.weight > 0);
  const byKey = Object.fromEntries(FIELDS.map(f => [f.key, f]));

  const GROUPS = [
    { id: 'ctx', fields: ['context', 'need'] },
    { id: 'data', fields: ['data'] },
    { id: 'result', fields: ['expected_result'] },
    { id: 'success', fields: ['success_criteria'] },
    { id: 'constraints', fields: ['constraints'] },
    { id: 'users', fields: ['users'] },
    { id: 'link', fields: ['contact', 'interaction_format'] },
  ].map(g => Object.defineProperty(g, 'label', { get: () => tr(`group.${g.id}`), enumerable: true }));

  // caption — рукописная подпись уровня в метафоре кузницы, color — цвет «магии» уровня.
  const LEVELS = [
    { id: 'priority', min: 90, color: '#C8FF3D' },
    { id: 'ready', min: 70, color: '#7C5CFF' },
    { id: 'working', min: 40, color: '#FFB347' },
    { id: 'draft', min: 0, color: '#E5484D' },
  ].map(l => localized(l, `level.${l.id}`, ['label', 'caption', 'desc']));

  // Температура слитка: холодный пепел → ржавчина → жар → янтарь → добела.
  const HEAT = [[0, [58, 61, 74]], [25, [138, 59, 46]], [50, [255, 107, 26]], [75, [255, 179, 71]], [100, [255, 248, 231]]];
  function heatColor(score) {
    const s = Math.max(0, Math.min(100, score));
    for (let i = 1; i < HEAT.length; i++) {
      const [b, cb] = HEAT[i], [a, ca] = HEAT[i - 1];
      if (s <= b) {
        const k = (s - a) / (b - a);
        return `rgb(${ca.map((c, j) => Math.round(c + (cb[j] - c) * k)).join(',')})`;
      }
    }
    return 'rgb(255,248,231)';
  }

  // Оценка сложности задачи 1–10 для Hunt Map (ось X): по ключевым словам ожидаемого результата и ограничений.
  const HARD = /(модел|машинн|ml|нейро|компьютерн\w* зрен|распозна|прогноз|оптимизац|маршрут|vrp|интеграц|api|риск|скоринг|model|machine learning|neural|computer vision|recogni|forecast|optimi|route|integrat|scoring)/gi;
  const MID = /(бот|дашборд|сервис|приложен|панел|отч[её]т|аналит|автоматиз|crm|есеп|қосымша|bot|dashboard|service|app|panel|report|analyt|automat)/gi;
  function complexity(card) {
    const t = [card.expected_result, card.constraints, card.need, card.data].join(' ');
    const hard = (t.match(HARD) || []).length, mid = (t.match(MID) || []).length;
    return Math.max(1, Math.min(10, 2 + hard * 2 + mid + Math.floor(t.length / 250)));
  }

  // Доля баллов за поле: пусто 0, слишком кратко 0.3, частично 0.7, полностью 1.
  const RATIO = { empty: 0, short: 0.3, partial: 0.7, full: 1 };

  function evaluateField(key, value) {
    const f = byKey[key];
    const t = String(value || '').trim();
    if (!t) return { status: 'empty', ratio: 0, note: tr('note.empty') };
    const isContact = key === 'contact';
    if (!isContact && t.length < 20) return { status: 'short', ratio: RATIO.short, note: tr('note.short') };
    if (f.strong(t)) return { status: 'full', ratio: RATIO.full, note: tr('note.full') };
    if (isContact && t.length < 5) return { status: 'short', ratio: RATIO.short, note: tr('note.noContact') };
    return { status: 'partial', ratio: RATIO.partial, note: tr('note.partial') };
  }

  function levelFor(total) {
    return LEVELS.find(l => total >= l.min);
  }

  function score(card) {
    card = card || {};
    const fields = {};
    let total = 0;
    for (const f of SCORED) {
      const ev = evaluateField(f.key, card[f.key]);
      const points = Math.round(f.weight * ev.ratio);
      fields[f.key] = { ...ev, points, max: f.weight, label: f.label };
      total += points;
    }
    const groups = GROUPS.map(g => ({
      ...g,
      points: g.fields.reduce((s, k) => s + fields[k].points, 0),
      max: g.fields.reduce((s, k) => s + byKey[k].weight, 0),
    }));
    const missing = SCORED
      .filter(f => fields[f.key].status !== 'full')
      .map(f => ({ key: f.key, label: f.label, gain: f.weight - fields[f.key].points, hint: f.hint, status: fields[f.key].status }))
      .sort((a, b) => b.gain - a.gain);
    return { total, fields, groups, missing, level: levelFor(total) };
  }

  // Правило каталога: по рейтингу (убывание), при равенстве — более свежие выше.
  function catalogSort(tasks) {
    return [...tasks].sort((a, b) => (b.score - a.score) || ((b.publishedAt || 0) - (a.publishedAt || 0)));
  }

  return { FIELDS, SCORED, GROUPS, LEVELS, byKey, evaluateField, score, levelFor, catalogSort, heatColor, complexity };
})();

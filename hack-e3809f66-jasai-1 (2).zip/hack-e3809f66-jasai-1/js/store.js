﻿// Хранилище состояния в localStorage. Без бэкенда: всё работает при открытии index.html.
window.Store = (function () {
  const KEY = 'task-forge-v3';
  const VERSION = 3;
  const DAY = 86400000;
  let state = null;

  function uid(prefix) {
    return prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  }

  function seedState() {
    const now = Date.now();
    const S = window.SEED;
    const tasks = S.cards.map(c => {
      const sc = window.Scoring.score(c.card);
      const at = now - c.daysAgo * DAY;
      return {
        id: c.id, company: c.company, industry: c.industry, draftText: '',
        card: { ...c.card }, score: sc.total, status: 'published',
        createdAt: at, publishedAt: at, confirmedAt: at,
        history: [{ at, score: sc.total, note: 'published' }],
      };
    });
    const proposals = S.proposals.map(p => ({
      ...p, createdAt: now - p.daysAgo * DAY,
      stages: p.stages.map(s => ({ id: s.id, points: s.points, at: now - s.daysAgo * DAY })),
    }));
    return {
      version: VERSION,
      tasks, proposals,
      teams: S.teams.map(t => ({ ...t })),
      companies: [...S.companies],
      role: 'business',
      currentCompany: S.companies[0],
      currentTeamId: S.teams[0].id,
      // mode 'auto': Grok (xAI) → OpenAI → эвристика по наличию ключей; 'local': только эвристика.
      settings: { mode: 'auto', apiKey: '', model: window.AI.DEFAULT_MODEL, xaiKey: '', xaiModel: 'grok-3-mini' },
      achievements: {},
      aiLog: [],
    };
  }

  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && parsed.version === VERSION && Array.isArray(parsed.tasks)) { state = parsed; return state; }
      }
    } catch (e) { /* повреждённые данные — пересоздаём */ }
    state = seedState();
    save();
    return state;
  }

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { /* приватный режим — работаем в памяти */ }
  }

  function reset() {
    state = seedState();
    save();
    return state;
  }

  const get = () => state;
  const task = id => state.tasks.find(t => t.id === id);
  const team = id => state.teams.find(t => t.id === id);
  const proposalsFor = taskId => state.proposals.filter(p => p.taskId === taskId).sort((a, b) => b.createdAt - a.createdAt);
  const inWork = taskId => state.proposals.some(p => p.taskId === taskId && p.status === 'accepted');
  const teamPoints = teamId => state.proposals
    .filter(p => p.teamId === teamId)
    .reduce((s, p) => s + p.stages.reduce((x, st) => x + st.points, 0), 0);

  function published() {
    return window.Scoring.catalogSort(state.tasks.filter(t => t.status === 'published'));
  }

  function catalogPosition(taskId) {
    const i = published().findIndex(t => t.id === taskId);
    return i < 0 ? null : i + 1;
  }

  // Подтверждение карточки: только здесь начисляются баллы и пересчитывается рейтинг.
  function confirmCard({ taskId, company, industry, draftText, draftScore, card }) {
    const sc = window.Scoring.score(card);
    const now = Date.now();
    let t = taskId && task(taskId);
    if (!t) {
      t = { id: uid('t'), company, industry, draftText, card: {}, score: 0, status: 'unpublished', createdAt: now, history: [] };
      if (typeof draftScore === 'number') t.history.push({ at: now, score: draftScore, note: 'draft' });
      state.tasks.push(t);
    }
    const prev = t.history.length ? t.history[t.history.length - 1].score : null;
    t.card = { ...card };
    t.industry = industry || t.industry;
    t.score = sc.total;
    t.confirmedAt = now;
    if (prev !== sc.total) t.history.push({ at: now, score: sc.total, note: t.history.length <= 1 ? 'first' : 'more' });
    save();
    return t;
  }

  function publish(taskId) {
    const t = task(taskId);
    if (!t) return null;
    t.status = 'published';
    t.publishedAt = t.publishedAt || Date.now();
    save();
    return t;
  }

  function addProposal(p) {
    const pr = { id: uid('p'), status: 'pending', createdAt: Date.now(), stages: [], ...p };
    state.proposals.push(pr);
    save();
    return pr;
  }

  // Решение по контракту принимает только бизнес — вызывается исключительно из обработчика кнопки.
  function setProposalStatus(id, status) {
    const p = state.proposals.find(x => x.id === id);
    if (p) { p.status = status; p.decidedAt = Date.now(); save(); }
    return p;
  }

  function confirmStage(id, stageId) {
    const p = state.proposals.find(x => x.id === id);
    const st = window.SEED.stages.find(s => s.id === stageId);
    if (!p || !st || p.status !== 'accepted') return null;
    if (p.stages.some(s => s.id === st.id)) return null;
    p.stages.push({ id: st.id, points: st.points, at: Date.now() });
    save();
    return p;
  }

  function addCompany(name) {
    if (!state.companies.includes(name)) state.companies.push(name);
    state.currentCompany = name;
    save();
  }

  /** Выдаёт достижение; возвращает описание, если оно получено впервые. */
  function unlock(id) {
    if (state.achievements[id]) return null;
    state.achievements[id] = Date.now();
    save();
    return window.SEED.achievements.find(a => a.id === id);
  }

  function logAI(entry) {
    state.aiLog.unshift(entry);
    state.aiLog = state.aiLog.slice(0, 20);
    save();
  }

  return {
    load, save, reset, get, task, team, proposalsFor, inWork, teamPoints, published, catalogPosition,
    confirmCard, publish, addProposal, setProposalStatus, confirmStage, addCompany, unlock, logAI,
  };
})();

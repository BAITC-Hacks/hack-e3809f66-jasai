// Тестовые сценарии для формулы рейтинга, уровней, локального ИИ и валидатора ответов модели.
(function () {
  const S = window.Scoring, AI = window.AI, I18N = window.I18N;
  I18N.setLang('ru', false);             // тесты проверяют русские тексты; выбор пользователя не трогаем
  const results = [];
  function test(name, fn) {
    try { fn(); results.push({ name, ok: true }); }
    catch (e) { results.push({ name, ok: false, msg: e.message }); }
  }
  function eq(a, b, msg) { if (a !== b) throw new Error(`${msg || ''} ожидалось ${JSON.stringify(b)}, получено ${JSON.stringify(a)}`); }
  function ok(v, msg) { if (!v) throw new Error(msg || 'условие не выполнено'); }

  const full = {
    title: 'Оптимизация маршрутов курьеров',
    context: 'Диспетчеры вручную распределяют около 400 заказов в день между 35 курьерами, маршруты пересекаются и заказы опаздывают.',
    need: 'Нужно автоматизировать построение маршрутов и сократить время доставки.',
    users: 'Диспетчеры смены (6 человек) и курьеры.',
    data: 'Выгрузка заказов за 6 месяцев в CSV, GPS-треки курьеров.',
    expected_result: 'Прототип сервиса, который строит маршруты и показывает их на карте.',
    success_criteria: 'Пробег снижается на 15%, опоздания ниже 5%.',
    constraints: 'Срок — 8 недель, Python, NDA.',
    contact: 'ops@kztrans.kz',
    interaction_format: 'Еженедельный созвон в Google Meet.',
  };

  test('Сумма весов = 100', () => eq(S.SCORED.reduce((s, f) => s + f.weight, 0), 100));
  test('Группы соответствуют шкале кейса (20/20/15/15/10/10/10)', () => {
    eq(S.score(full).groups.map(g => g.max).join(','), '20,20,15,15,10,10,10');
  });
  test('Пустая карточка → 0 баллов, уровень «Черновик»', () => {
    const sc = S.score(AI.emptyCard());
    eq(sc.total, 0); eq(sc.level.id, 'draft'); eq(sc.missing.length, 9);
  });
  test('Полная карточка → 100 баллов, «Приоритетная»', () => {
    const sc = S.score(full);
    eq(sc.total, 100); eq(sc.level.id, 'priority'); eq(sc.missing.length, 0);
  });
  test('Границы уровней 39/40/69/70/89/90', () => {
    eq(S.levelFor(39).id, 'draft'); eq(S.levelFor(40).id, 'working');
    eq(S.levelFor(69).id, 'working'); eq(S.levelFor(70).id, 'ready');
    eq(S.levelFor(89).id, 'ready'); eq(S.levelFor(90).id, 'priority'); eq(S.levelFor(100).id, 'priority');
  });
  test('Критерии успеха без цифр — частичный балл (11 из 15)', () => {
    const sc = S.score({ ...full, success_criteria: 'Команда диспетчеров довольна результатом работы' });
    eq(sc.fields.success_criteria.points, 11); eq(sc.total, 96);
  });
  test('Слишком короткое поле — 30% веса', () => {
    eq(S.score({ ...full, data: 'Есть Excel' }).fields.data.points, 6);
  });
  test('Рейтинг пересчитывается после дополнения и растёт', () => {
    const before = S.score({ ...full, data: '', success_criteria: '' }).total;
    const after = S.score(full).total;
    eq(before, 65); eq(after, 100); ok(after > before);
  });
  test('Список недостающего отсортирован по потенциальному приросту', () => {
    const m = S.score({ ...full, data: '', constraints: '' }).missing;
    eq(m[0].key, 'data'); eq(m[0].gain, 20); eq(m[1].gain, 10);
  });
  test('Каталог: сортировка по рейтингу, при равенстве — новее выше', () => {
    const list = S.catalogSort([{ id: 'a', score: 50, publishedAt: 1 }, { id: 'b', score: 90, publishedAt: 1 }, { id: 'c', score: 50, publishedAt: 2 }]);
    eq(list.map(t => t.id).join(''), 'bca');
  });

  test('Локальный анализ слабого черновика: ≥3 вопросов, низкий рейтинг', () => {
    const r = AI.analyzeLocal({ draft: 'Хотим чат-бота для кофейни, чтобы принимать заказы.' });
    ok(r.questions.length >= 3, 'вопросов ' + r.questions.length);
    ok(S.score(r.fields).total < 40, 'рейтинг ' + S.score(r.fields).total);
    ok(r.fields.title.length > 0, 'нет названия');
  });
  test('Локальный анализ не придумывает факты (все слова из черновика)', () => {
    const draft = SEED.drafts[3].text;
    const r = AI.analyzeLocal({ draft });
    eq(AI.groundingCheck(r.fields, draft).length, 0);
  });
  test('Полный черновик → «рабочая» или выше, но всё равно ≥3 вопросов', () => {
    const r = AI.analyzeLocal({ draft: SEED.drafts[4].text });
    ok(S.score(r.fields).total >= 40, 'рейтинг ' + S.score(r.fields).total);
    ok(r.questions.length >= 3);
  });
  test('Ответы на вопросы попадают в свои поля и повышают рейтинг', () => {
    const draft = 'Хотим чат-бота для кофейни, чтобы принимать заказы.';
    const a = AI.analyzeLocal({ draft });
    const before = S.score(a.fields).total;
    const c = AI.buildCardLocal({ draft, fields: a.fields, answers: [
      { field: 'data', answer: 'меню в Excel, 120 позиций, история заказов из кассы за 3 месяца' },
      { field: 'success_criteria', answer: '30% заказов через бота за первый месяц' },
    ] }).card;
    ok(c.data.includes('Excel')); ok(c.success_criteria.includes('30%'));
    ok(S.score(c).total > before + 30, `${before} → ${S.score(c).total}`);
  });

  test('Валидатор: не-JSON → ошибка парсинга и fallback', () => {
    const log = { errors: [], grounding: [], fallback: false };
    const out = AI.processRaw('analyze', { draft: 'Нужен дашборд по доставкам.' }, 'Вот ответ: {oops', log);
    ok(log.fallback); ok(/JSON/.test(log.errors[0])); ok(out.questions.length >= 3);
  });
  test('Валидатор: нарушение схемы → fallback', () => {
    const log = { errors: [], grounding: [], fallback: false };
    AI.processRaw('analyze', { draft: 'Нужен дашборд.' }, JSON.stringify({ fields: { title: 1 }, questions: [{ field: 'x', question: '' }] }), log);
    ok(log.fallback); ok(log.errors.length >= 3, log.errors.join('; '));
  });
  test('Валидатор: выдуманные цифры удаляются, пустые вопросы дополняются до 3', () => {
    const draft = 'Хотим чат-бота для кофейни, чтобы принимать заказы.';
    const raw = JSON.stringify({ fields: { ...AI.emptyCard(), title: 'Чат-бот для кофейни', success_criteria: 'Конверсия не ниже 35%' }, questions: [{ field: 'data', question: 'Какие данные есть?' }] });
    const log = { errors: [], grounding: [], fallback: false };
    const out = AI.processRaw('analyze', { draft }, raw, log);
    ok(!log.fallback); eq(out.fields.success_criteria, ''); eq(log.grounding.length, 1);
    eq(out.questions.length, 3);
  });
  test('Валидатор: корректный ответ модели принимается без изменений', () => {
    const draft = 'Хотим чат-бота для кофейни, чтобы принимать заказы.';
    const fields = { ...AI.emptyCard(), title: 'Чат-бот для кофейни', need: 'Принимать заказы через чат-бота кофейни.' };
    const raw = JSON.stringify({ fields, questions: [{ field: 'data', question: 'a?' }, { field: 'users', question: 'b?' }, { field: 'success_criteria', question: 'c?' }] });
    const log = { errors: [], grounding: [], fallback: false };
    const out = AI.processRaw('analyze', { draft }, raw, log);
    eq(log.errors.length, 0); eq(log.grounding.length, 0); eq(out.fields.need, fields.need);
  });

  test('Рекомендации: только задачи с рейтингом ≥ 40 и совпадением навыков', () => {
    const tasks = [
      { id: 'a', score: 80, industry: 'Логистика', card: { title: 'Маршруты', need: 'дашборд' } },
      { id: 'b', score: 20, industry: 'Логистика', card: { title: 'Дашборд', need: 'дашборд' } },
      { id: 'c', score: 90, industry: 'Медицина', card: { title: 'Что-то', need: 'другое' } },
    ];
    const r = AI.recommend(SEED.teams[2], tasks);
    eq(r.map(x => x.task.id).join(','), 'a');
  });
  test('Seed-карточки покрывают все 4 уровня готовности', () => {
    const levels = new Set(SEED.cards.map(c => S.levelFor(S.score(c.card).total).id));
    eq(levels.size, 4, [...levels].join(',') + ' — ');
  });
  test('Seed: 5 черновиков (от ~15 до 95+ баллов), 5 карточек, 5 команд, 5 контрактов', () => {
    eq(SEED.drafts.length, 5); eq(SEED.cards.length, 5); eq(SEED.teams.length, 5); eq(SEED.proposals.length, 5);
    const scores = SEED.drafts.map(d => S.score(AI.extractLocal(d.text)).total);
    ok(Math.min(...scores) <= 20, 'min ' + Math.min(...scores)); ok(Math.max(...scores) >= 90, 'max ' + Math.max(...scores));
    ok(SEED.proposals.every(p => p.signature && p.signature.d && p.weeks > 0), 'подписи и сроки');
  });
  test('Подписи уровней в метафоре кузницы', () => {
    eq(S.levelFor(10).caption, 'Слиток не закалён'); eq(S.levelFor(50).caption, 'Ещё удар молота');
    eq(S.levelFor(80).caption, 'Почти клинок'); eq(S.levelFor(95).caption, 'Оружие готово');
  });
  test('Температура слитка: холодный пепел → добела', () => {
    eq(S.heatColor(0), 'rgb(58,61,74)'); eq(S.heatColor(100), 'rgb(255,248,231)'); eq(S.heatColor(50), 'rgb(255,107,26)');
  });
  test('Сложность для Hunt Map в диапазоне 1–10, ML-задача сложнее бота', () => {
    const ml = S.complexity({ expected_result: 'Модель прогноза и оптимизация маршрутов через API', constraints: '', need: '', data: '' });
    const bot = S.complexity({ expected_result: 'Простой бот', constraints: '', need: '', data: '' });
    ok(ml >= 1 && ml <= 10 && bot >= 1 && bot <= 10); ok(ml > bot, `${ml} vs ${bot}`);
  });
  test('Демо-сценарий: рейтинг растёт с каждым ударом и доходит до «Готовой»', () => {
    const D = SEED.demo;
    const a = AI.analyzeLocal({ draft: D.draft });
    const trail = [S.score(a.fields).total];
    const answers = [];
    for (const q of a.questions) {
      if (!D.answers[q.field]) continue;
      answers.push({ field: q.field, answer: D.answers[q.field] });
      trail.push(S.score(AI.buildCardLocal({ draft: D.draft, fields: a.fields, answers }).card).total);
    }
    let card = AI.buildCardLocal({ draft: D.draft, fields: a.fields, answers }).card;
    card = { ...card, ...D.edits };
    trail.push(S.score(card).total);
    ok(trail.every((v, i) => !i || v > trail[i - 1]), 'рост: ' + trail.join('→'));
    ok(trail[0] < 40, 'старт ' + trail[0]); eq(S.levelFor(trail[trail.length - 1]).id, 'ready', 'финал ' + trail.join('→') + ' — ');
    ok(a.questions.some(q => !D.answers[q.field]), 'один вопрос пропущен');
  });
  test('Ответ модели без hint получает подсказку из справочника полей', () => {
    const raw = JSON.stringify({ fields: { ...AI.emptyCard(), title: 'Бот' }, questions: [{ field: 'data', question: 'a?' }, { field: 'users', question: 'b?' }, { field: 'constraints', question: 'c?' }] });
    const log = { errors: [], grounding: [], fallback: false };
    const out = AI.processRaw('analyze', { draft: 'Нужен бот для заказов.' }, raw, log);
    ok(out.questions.every(q => q.hint && q.hint.length > 10));
  });

  // ---------- AI-провайдеры ----------
  test('Провайдер по приоритету: Grok → OpenAI → эвристика', () => {
    const P = window.AIProvider;
    eq(P.get({ mode: 'auto', xaiKey: 'xai-1', apiKey: 'sk-1' }).name, 'grok', 'оба ключа —');
    eq(P.get({ mode: 'auto', xaiKey: '', apiKey: 'sk-1' }).name, 'openai', 'только OpenAI —');
    eq(P.get({ mode: 'auto', xaiKey: '  ', apiKey: '' }).name, 'fallback', 'пробелы вместо ключа —');
    eq(P.get({ mode: 'local', xaiKey: 'xai-1', apiKey: 'sk-1' }).name, 'fallback', 'режим «только эвристика» —');
    eq(P.get({ mode: 'openai', apiKey: 'sk-1' }).name, 'openai', 'старые настройки —');
    eq(P.get({}).name, 'fallback', 'пустые настройки —');
  });
  test('Grok идёт на api.x.ai с моделью по умолчанию, OpenAI — на api.openai.com', () => {
    const g = window.AIProvider.get({ xaiKey: 'xai-1' }), o = window.AIProvider.get({ apiKey: 'sk-1', model: 'gpt-x' });
    eq(g.url, 'https://api.x.ai/v1/chat/completions'); eq(g.model, 'grok-3-mini'); eq(g.apiKey, 'xai-1');
    eq(o.url, 'https://api.openai.com/v1/chat/completions'); eq(o.model, 'gpt-x');
  });
  test('Ответ Grok в обёртке ```json проходит парсинг', () => {
    const r = AI.parseJson('```json\n{"a":1}\n```');
    ok(r.ok && r.value.a === 1, JSON.stringify(r));
  });

  // ---------- Локализация ----------
  test('Словари ru / kk / en содержат одинаковые ключи одинакового типа', () => {
    const { ru, kk, en } = I18N.DICT;
    const type = v => Array.isArray(v) ? 'array' : typeof v;
    const problems = [];
    for (const [name, d] of [['kk', kk], ['en', en]]) {
      for (const k of Object.keys(ru)) {
        if (!(k in d)) problems.push(`${name}: нет ключа ${k}`);
        else if (type(d[k]) !== type(ru[k])) problems.push(`${name}: другой тип у ${k}`);
        else if (Array.isArray(ru[k]) && d[k].length !== ru[k].length) problems.push(`${name}: другая длина ${k}`);
      }
      for (const k of Object.keys(d)) if (!(k in ru)) problems.push(`${name}: лишний ключ ${k}`);
    }
    ok(!problems.length, problems.slice(0, 5).join('; '));
  });
  test('Функции-переводы работают с числами 0, 1, 2, 5, 21 без «undefined»', () => {
    for (const lang of ['ru', 'kk', 'en']) {
      for (const [k, v] of Object.entries(I18N.DICT[lang])) {
        if (typeof v !== 'function') continue;
        for (const n of [0, 1, 2, 5, 21]) {
          const out = v(n, n, n);
          ok(typeof out === 'string' && !out.includes('undefined'), `${lang}.${k}(${n}) → ${out}`);
        }
      }
    }
  });
  test('Русское склонение: 1 задача, 2 задачи, 5 задач, 21 задача, 11 задач', () => {
    const f = I18N.DICT.ru['tile.contracts'];
    eq(f(1), '1 контракт'); eq(f(3), '3 контракта'); eq(f(5), '5 контрактов'); eq(f(21), '21 контракт'); eq(f(11), '11 контрактов');
  });
  test('Подписи уровней и полей переключаются вместе с языком', () => {
    I18N.setLang('en', false);
    const en = [S.levelFor(95).caption, S.byKey.data.label, S.score({}).groups[0].label];
    I18N.setLang('kk', false);
    const kk = [S.levelFor(95).caption, S.byKey.data.label];
    I18N.setLang('ru', false);
    eq(en.join('|'), 'Weapon ready|Data and materials|Context and need'); eq(kk.join('|'), 'Қару дайын|Деректер мен материалдар');
  });
  test('Английская полная карточка получает 100 баллов', () => {
    const card = {
      title: 'Courier route optimisation',
      context: 'Dispatchers manually assign around 400 orders a day to 35 couriers, so routes overlap and many deliveries are late.',
      need: 'We need to automate route planning and reduce delivery time.',
      users: 'Shift dispatchers (6 people) and couriers.',
      data: 'Order export for 6 months in CSV and courier GPS tracks.',
      expected_result: 'A prototype service that builds daily routes and shows them on a map.',
      success_criteria: 'Mileage drops by 15%, late deliveries below 5%.',
      constraints: 'Deadline: 8 weeks, Python, NDA.',
      contact: 'ops@example.com',
      interaction_format: 'Weekly call in Google Meet.',
    };
    eq(S.score(card).total, 100);
  });
  test('Казахская подробная карточка получает не меньше 90 баллов', () => {
    const card = {
      title: 'Курьерлердің бағыттарын оңтайландыру',
      context: 'Диспетчерлер күн сайын 400-ге жуық тапсырысты 35 курьерге қолмен бөледі, сондықтан бағыттар қиылысып, тапсырыстар кешігеді.',
      need: 'Бағыттарды құруды автоматтандыру және жеткізу уақытын азайту қажет.',
      users: 'Ауысым диспетчерлері (6 адам) және курьерлер.',
      data: '6 айлық тапсырыстар экспорты CSV форматында және GPS деректері.',
      expected_result: 'Күнделікті бағыттарды құрып, картада көрсететін сервис прототипі.',
      success_criteria: 'Жүгіріс 15%-ға азаяды, кешігулер 5%-дан төмен.',
      constraints: 'Мерзімі — 8 апта, Python, NDA.',
      contact: 'ops@example.kz',
      interaction_format: 'Аптасына бір рет Zoom-да қоңырау.',
    };
    ok(S.score(card).total >= 90, 'рейтинг ' + S.score(card).total);
  });
  test('Английский черновик разбирается эвристикой: потребность найдена, ≥3 вопросов на английском', () => {
    I18N.setLang('en', false);
    const r = AI.analyzeLocal({ draft: 'We want to understand why customers leave.' });
    I18N.setLang('ru', false);
    ok(r.fields.need.includes('We want'), JSON.stringify(r.fields)); ok(r.questions.length >= 3);
    ok(/^[A-Za-z]/.test(r.questions[0].question), r.questions[0].question);
  });

  const failed = results.filter(r => !r.ok).length;
  document.getElementById('summary').innerHTML = failed
    ? `<span class="fail">FAILED: ${failed} из ${results.length}</span>`
    : `<span class="pass">PASSED: ${results.length} из ${results.length}</span>`;
  document.getElementById('out').innerHTML = results.map(r =>
    `<li class="${r.ok ? 'pass' : 'fail'}">${r.ok ? '✔' : '✘'} ${r.name}${r.ok ? '' : ' — ' + r.msg}</li>`).join('');
  document.title = failed ? 'FAILED' : 'PASSED';
})();

﻿// Сид-данные: 5 черновиков, 5 карточек, 5 команд, 5 контрактов (откликов).
// Баллы карточек не хардкодятся — рассчитываются формулой Scoring.score при первой загрузке.
window.SEED = (function () {
  // Процедурная «подпись» команды для сид-контрактов: росчерк из синусоид, SVG path в viewBox 300×100.
  function signature(seed) {
    let d = '';
    for (let s = 0; s < 2; s++) {
      const pts = [];
      for (let i = 0; i <= 40; i++) {
        const t = i / 40;
        const x = 20 + s * 150 + t * (s ? 120 : 140);
        const y = 55 + Math.sin(t * (6 + seed % 4) + seed) * (22 - s * 8) + Math.cos(t * 13 + seed * 2) * 7;
        pts.push(`${x.toFixed(1)} ${y.toFixed(1)}`);
      }
      d += 'M' + pts.join(' L') + ' ';
    }
    return { d: d.trim(), w: 300, h: 100 };
  }

  return {
    industries: ['Retail', 'FinTech', 'EdTech', 'HoReCa', 'Logistics', 'MedTech', 'AgroTech'],

    companies: ['Bean&Go', 'SmartShop', 'QazPay', 'KZ Trans Logistics', 'Bilim+'],

    drafts: [
      { id: 'd1', company: 'Bean&Go', industry: 'HoReCa',
        text: 'Хотим чат-бота для кофейни, чтобы принимать заказы.' },
      { id: 'd2', company: 'SmartShop', industry: 'Retail',
        text: 'Хотим понять, почему клиенты уходят.' },
      { id: 'd3', company: 'QazPay', industry: 'FinTech',
        text: 'Клиенты микрозаймов часто пропускают дату платежа, и растёт просрочка. Нужно сократить число просрочек. Есть выгрузка платежей за 2024 год в CSV.' },
      { id: 'd4', company: 'KZ Trans Logistics', industry: 'Logistics',
        text: 'У нас 35 курьеров, диспетчеры вручную строят маршруты в Excel каждое утро. Нужно сократить пробег и число опозданий. Хотим прототип сервиса построения маршрутов.' },
      { id: 'd5', company: 'Bilim+', industry: 'EdTech',
        text: 'Кураторы онлайн-школы вручную проверяют около 300 домашних заданий по математике в неделю и отвечают ученикам с задержкой до 3 дней. Нужно сократить время проверки домашних заданий в 10 раз. Пользователи — 12 кураторов и ученики школы. Хотим прототип автопроверки тестовых заданий с отчётом для куратора. Есть 2000 проверенных работ в Google Sheets. Успех — проверка занимает меньше 1 минуты и совпадает с оценкой куратора в 90% случаев. Срок — 6 недель, стек Python. Контакт: aigerim@bilimplus.kz. Созвоны раз в неделю в Zoom.' },
    ],

    cards: [
      { id: 't1', company: 'KZ Trans Logistics', industry: 'Logistics', daysAgo: 6,
        card: {
          title: 'Оптимизация маршрутов курьеров по Алматы',
          context: 'Диспетчеры вручную распределяют около 400 заказов в день между 35 курьерами. Маршруты строятся по опыту, из-за этого курьеры пересекаются в одних районах, а часть заказов опаздывает.',
          need: 'Нужно автоматизировать построение маршрутов и сократить время доставки и пробег курьеров.',
          users: 'Диспетчеры смены (6 человек) и курьеры, которые получают маршрут в мобильном приложении.',
          data: 'Выгрузка заказов за 6 месяцев в CSV (адрес, окно доставки, вес), GPS-треки курьеров, справочник зон доставки. Доступ к тестовому API заказов.',
          expected_result: 'Прототип сервиса, который по списку заказов на день строит маршруты для каждого курьера и показывает их на карте.',
          success_criteria: 'Средний пробег на курьера снижается на 15%, доля опозданий — ниже 5% на исторических данных.',
          constraints: 'Срок — 8 недель. Python или JavaScript, без платных картографических API. Данные клиентов обезличены, NDA.',
          contact: 'Руслан, руководитель диспетчерской: ops@kztrans.kz, +7 701 555 12 34',
          interaction_format: 'Еженедельный созвон в Google Meet по вторникам, ответы в Telegram-чате в течение рабочего дня.',
        } },
      { id: 't2', company: 'QazPay', industry: 'FinTech', daysAgo: 4,
        card: {
          title: 'Telegram-бот напоминаний о платежах',
          context: 'Около 18% клиентов микрозаймов пропускают дату платежа и не предупреждают об этом. Операторы колл-центра обзванивают клиентов вручную, но не успевают.',
          need: 'Хотим автоматически напоминать клиентам о платеже и давать возможность оплатить или перенести дату.',
          users: 'Заёмщики и операторы колл-центра.',
          data: 'Графики платежей хранятся в учётной системе.',
          expected_result: 'Telegram-бот, который присылает напоминание за 3 дня и в день платежа и принимает подтверждение.',
          success_criteria: 'Доля просрочек снижается до 10%.',
          constraints: 'Персональные данные клиентов нельзя выносить за пределы компании.',
          contact: 'it@qazpay.kz',
          interaction_format: '',
        } },
      { id: 't3', company: 'SmartShop', industry: 'Retail', daysAgo: 3,
        card: {
          title: 'Контроль выкладки товара по фото полок',
          context: 'Мерчандайзеры не успевают проверять полки.',
          need: 'Нужно быстрее находить пустые полки, чтобы снизить потери продаж.',
          users: 'Мерчандайзеры магазинов сети.',
          data: 'Есть несколько сотен фото полок, часть размечена.',
          expected_result: 'Модель или приложение для распознавания.',
          success_criteria: '',
          constraints: '',
          contact: 'it@smartshop.kz',
          interaction_format: 'Встреча по запросу.',
        } },
      { id: 't4', company: 'Bean&Go', industry: 'HoReCa', daysAgo: 2,
        card: {
          title: 'Программа лояльности для кофейни',
          context: 'Гости не возвращаются.',
          need: 'Хотим программу лояльности.',
          users: '',
          data: '',
          expected_result: 'Приложение',
          success_criteria: '',
          constraints: '',
          contact: 'Менеджер Аружан, +7 777 100 20 30',
          interaction_format: '',
        } },
      { id: 't5', company: 'Bilim+', industry: 'EdTech', daysAgo: 1,
        card: {
          title: 'Аналитика оттока учеников онлайн-школы',
          context: 'Около 25% учеников бросают курс в первый месяц. Мы не понимаем, на каком этапе и почему они уходят, решения принимаются интуитивно.',
          need: 'Необходимо выявить основные причины оттока и найти учеников в зоне риска заранее.',
          users: 'Кураторы групп и руководитель учебного отдела.',
          data: 'Логи посещения уроков и сдачи домашних заданий из LMS за год (JSON), анкеты обратной связи в Google Sheets.',
          expected_result: 'Дашборд с воронкой прохождения курса и список учеников с высоким риском ухода.',
          success_criteria: 'Модель находит не менее 70% ушедших учеников за 2 недели до ухода на исторических данных.',
          constraints: 'Срок — 6 недель.',
          contact: 'aigerim@bilimplus.kz',
          interaction_format: 'Созвоны раз в неделю в Zoom.',
        } },
    ],

    teams: [
      { id: 'tm1', name: 'Byte Nomads', interests: ['образование', 'отток клиентов', 'аналитика'], skills: ['машинное обучение', 'анализ данных'], tech: ['Python', 'pandas', 'scikit-learn'] },
      { id: 'tm2', name: 'Steppe Devs', interests: ['кофейни', 'заказы', 'веб-сервисы'], skills: ['frontend', 'backend', 'приложение'], tech: ['JavaScript', 'React', 'Node.js'] },
      { id: 'tm3', name: 'Data Batyrs', interests: ['логистика', 'платежи'], skills: ['дашборд', 'аналитика', 'оптимизация маршрутов'], tech: ['SQL', 'Power BI', 'Python'] },
      { id: 'tm4', name: 'Vision Lab', interests: ['ритейл', 'полки магазинов'], skills: ['компьютерное зрение', 'модель'], tech: ['PyTorch', 'OpenCV', 'Python'] },
      { id: 'tm5', name: 'BotFactory', interests: ['платежи', 'клиенты', 'кофейни'], skills: ['telegram-боты', 'бот', 'интеграции'], tech: ['Python', 'aiogram', 'PostgreSQL'] },
    ],

    proposals: [
      { id: 'p1', taskId: 't1', teamId: 'tm3', status: 'accepted', daysAgo: 5, signature: signature(3),
        idea: 'Кластеризация заказов по зонам и решение задачи маршрутизации (VRP) с окнами доставки через OR-Tools.',
        plan: '1) Анализ исторических данных; 2) базовый алгоритм VRP; 3) карта маршрутов; 4) сравнение с текущими маршрутами.',
        weeks: 7, link: 'https://github.com/data-batyrs/route-opt',
        stages: [{ id: 'prototype', points: 20, daysAgo: 1 }] },
      { id: 'p2', taskId: 't1', teamId: 'tm1', status: 'pending', daysAgo: 4, signature: signature(7),
        idea: 'Жадный алгоритм с последующей локальной оптимизацией и прогнозом загрузки курьеров по часам.',
        plan: 'Недели 1–2: данные и метрики; 3–5: алгоритм и оптимизация; 6: интерфейс карты для диспетчеров.',
        weeks: 6, link: 'https://github.com/byte-nomads/courier-routes', stages: [] },
      { id: 'p3', taskId: 't2', teamId: 'tm5', status: 'pending', daysAgo: 3, signature: signature(11),
        idea: 'Бот на aiogram читает графики платежей из выгрузки и отправляет напоминания с кнопками «Оплатить / Перенести».',
        plan: 'Прототип бота за 2 недели, затем пилот на 500 клиентах ещё 2 недели с замером доли просрочек.',
        weeks: 4, link: 'https://github.com/botfactory/pay-reminder', stages: [] },
      { id: 'p4', taskId: 't5', teamId: 'tm1', status: 'pending', daysAgo: 1, signature: signature(5),
        idea: 'Воронка прохождения курса в дашборде и модель градиентного бустинга для оценки риска ухода ученика.',
        plan: 'EDA → признаки активности → модель → дашборд для кураторов → валидация на исторических данных.',
        weeks: 6, link: 'https://github.com/byte-nomads/churn', stages: [] },
      { id: 'p5', taskId: 't3', teamId: 'tm4', status: 'rejected', daysAgo: 2, signature: signature(9),
        idea: 'Дообучение готовой детекционной сети на фото полок и веб-демо, подсвечивающее пустые места.',
        plan: 'Разметка 300 фото → дообучение YOLO → веб-демо загрузки фото → отчёт о точности на тестовой выборке.',
        weeks: 5, link: 'https://github.com/vision-lab/shelf-scan', stages: [] },
    ],

    stages: [
      { id: 'prototype', points: 20 },
      { id: 'interim', points: 30 },
      { id: 'final', points: 50 },
    ],

    achievements: [
      // Названия и описания — в словаре I18N (ach.<id>.title / ach.<id>.desc).
      { id: 'first-strike', icon: '⚒' },
      { id: 'detail-master', icon: '◈' },
      { id: 'perfect-alloy', icon: '✦' },
      { id: 'generous-master', icon: '⚜' },
      { id: 'first-contract', icon: '✒' },
    ],

    // Сценарий кнопки «Смотреть демо».
    demo: {
      company: 'SmartShop', industry: 'Retail',
      draft: 'Хотим понять, почему клиенты уходят.',
      answers: {
        data: 'Выгрузка покупок по картам лояльности за 2 года в CSV, около 180000 клиентов, и результаты опросов NPS.',
        context: 'За последний год доля повторных покупок в сети упала, а маркетинг не понимает, какие клиенты уходят и после каких событий.',
        expected_result: 'Дашборд с сегментами клиентов по риску ухода и прототип модели, которая каждую неделю выдаёт список клиентов в зоне риска.',
        users: 'Маркетологи сети (5 человек) и руководитель CRM-отдела.',
      },
      edits: {
        success_criteria: 'Модель находит не менее 60% ушедших клиентов за месяц до ухода на исторических данных.',
        contact: 'crm@smartshop.kz',
        interaction_format: 'Созвон раз в неделю в Zoom, ответы в Telegram-чате.',
      },
      team: 'tm1',
      contract: {
        idea: 'Сегментация клиентов по RFM и модель градиентного бустинга, которая оценивает риск ухода по истории покупок.',
        plan: 'Неделя 1: данные и метрики; 2–3: RFM-сегменты и модель; 4: дашборд для маркетологов; 5: проверка на истории.',
        weeks: 5, link: 'https://github.com/byte-nomads/smartshop-churn',
      },
    },
  };
})();

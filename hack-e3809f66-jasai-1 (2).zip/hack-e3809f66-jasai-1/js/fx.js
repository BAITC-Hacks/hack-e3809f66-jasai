// Атмосфера кузницы: звук (Web Audio), искры (canvas), курсор, загрузчик, ритуал публикации,
// «шёпот» ИИ, view transitions. Каждый эффект привязан к событию метафоры, а не к декору.
window.FX = (function () {
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const touch = matchMedia('(pointer: coarse)').matches;
  const COLORS = { lime: '#C8FF3D', plasma: '#7C5CFF', amber: '#FFB347', ember: '#FF6B1A', white: '#FFF8E7', gold: '#FFE066', rust: '#E5484D' };

  // ================= Звук: синтез в реальном времени, без mp3 =================
  let ctx = null, master = null, drone = null, noiseBuf = null;
  let muted = true;
  try { muted = localStorage.getItem('forge-sound') !== 'on'; } catch (e) { /* нет доступа — без звука */ }

  function ensureCtx() {
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = 0.7;
      master.connect(ctx.destination);
      noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
      const data = noiseBuf.getChannelData(0);
      for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  // Гул горна: три осциллятора 45/60/90 Гц, «дыхание» через LFO.
  function startDrone() {
    if (drone || reduced || !ensureCtx()) return;
    const out = ctx.createGain();
    out.gain.value = 0;
    out.gain.linearRampToValueAtTime(1, ctx.currentTime + 2);
    out.connect(master);
    const lfo = ctx.createOscillator(), lfoGain = ctx.createGain();
    lfo.frequency.value = 0.12; lfoGain.gain.value = 0.012;
    lfo.connect(lfoGain); lfo.start();
    const oscs = [[45, 0.035], [60, 0.025], [90, 0.012]].map(([f, g]) => {
      const o = ctx.createOscillator(), gn = ctx.createGain();
      o.type = 'sine'; o.frequency.value = f; gn.gain.value = g;
      lfoGain.connect(gn.gain);
      o.connect(gn); gn.connect(out); o.start();
      return o;
    });
    drone = { out, oscs: [...oscs, lfo] };
  }
  function stopDrone() {
    if (!drone) return;
    const d = drone; drone = null;
    d.out.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.6);
    setTimeout(() => d.oscs.forEach(o => o.stop()), 700);
  }

  function noise(dur, filterType, freq, gain, when) {
    const src = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    src.buffer = noiseBuf; f.type = filterType; f.frequency.value = freq;
    const t = ctx.currentTime + (when || 0);
    g.gain.setValueAtTime(gain, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g); g.connect(master);
    src.start(t); src.stop(t + dur + 0.05);
    return f;
  }
  function tone(freq, dur, type, gain, when, endFreq) {
    const o = ctx.createOscillator(), g = ctx.createGain();
    const t = ctx.currentTime + (when || 0);
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if (endFreq) o.frequency.exponentialRampToValueAtTime(endFreq, t + dur);
    g.gain.setValueAtTime(gain, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + 0.05);
  }

  /** Проигрывает звуковой эффект: hammer | spark | rumble | paper | stamp. */
  function play(name) {
    if (muted || !ensureCtx()) return;
    switch (name) {
      case 'hammer': noise(0.09, 'lowpass', 1400, 0.5); tone(72, 0.35, 'sine', 0.5, 0, 40); tone(1320, 0.25, 'triangle', 0.06); tone(1980, 0.18, 'triangle', 0.03); break;
      case 'spark': for (let i = 0; i < 3; i++) tone(2200 + Math.random() * 2200, 0.05, 'sine', 0.05, i * 0.045); break;
      case 'rumble': { const f = noise(1.3, 'lowpass', 180, 0.6); f.frequency.linearRampToValueAtTime(420, ctx.currentTime + 0.8); tone(38, 1.2, 'sine', 0.4); break; }
      case 'paper': { const f = noise(0.35, 'bandpass', 900, 0.25); f.frequency.linearRampToValueAtTime(3200, ctx.currentTime + 0.3); break; }
      case 'stamp': tone(95, 0.2, 'sine', 0.7, 0, 50); noise(0.06, 'lowpass', 900, 0.6); break;
    }
  }

  function setMuted(m) {
    muted = m;
    try { localStorage.setItem('forge-sound', m ? 'off' : 'on'); } catch (e) { /* без сохранения */ }
    if (m) stopDrone(); else { ensureCtx(); startDrone(); play('spark'); }
  }
  // Браузер запускает звук только после жеста пользователя.
  addEventListener('pointerdown', () => { if (!muted) { ensureCtx(); startDrone(); } }, { once: true });

  // ================= Искры (canvas) =================
  const canvas = document.getElementById('fx-canvas');
  const g2d = canvas.getContext('2d');
  let parts = [], running = false;
  function resize() { canvas.width = innerWidth * devicePixelRatio; canvas.height = innerHeight * devicePixelRatio; }
  resize(); addEventListener('resize', resize);

  function loop() {
    const dpr = devicePixelRatio;
    g2d.clearRect(0, 0, canvas.width, canvas.height);
    const now = performance.now();
    parts = parts.filter(p => now - p.born < p.life);
    for (const p of parts) {
      if (now < p.born) continue;             // искра ещё не вылетела (задержка в очереди)
      const k = (now - p.born) / p.life;
      if (p.target) {                         // искра летит к цели (к «ядру» рейтинга)
        const e = 1 - Math.pow(1 - k, 3);
        p.x = p.sx + (p.target.x - p.sx) * e + Math.sin(k * Math.PI) * p.wobble;
        p.y = p.sy + (p.target.y - p.sy) * e - Math.sin(k * Math.PI) * 60;
      } else {                                // свободная искра: гравитация
        p.vy += 0.22; p.vx *= 0.99;
        p.x += p.vx; p.y += p.vy;
      }
      g2d.globalAlpha = 1 - k;
      g2d.fillStyle = p.color;
      g2d.shadowColor = p.color; g2d.shadowBlur = 12 * dpr;
      g2d.beginPath(); g2d.arc(p.x * dpr, p.y * dpr, p.size * dpr * (1 - k * 0.5), 0, Math.PI * 2); g2d.fill();
    }
    g2d.globalAlpha = 1;
    if (parts.length) requestAnimationFrame(loop); else running = false;
  }
  function kick() { if (!running) { running = true; requestAnimationFrame(loop); } }

  /** Взрыв искр в точке экрана. */
  function burst(x, y, opts) {
    const o = Object.assign({ count: 14, colors: [COLORS.gold, COLORS.ember, COLORS.white], power: 7, size: 2.4 }, opts);
    const n = reduced ? Math.min(4, o.count) : o.count;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, v = o.power * (0.4 + Math.random() * 0.8);
      parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - o.power * 0.6, size: o.size * (0.6 + Math.random() * 0.8),
        color: o.colors[i % o.colors.length], born: performance.now(), life: 1200 });
    }
    kick();
  }
  const center = el => { const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; };
  function burstAt(el, opts) { if (el) { const c = center(el); burst(c.x, c.y, opts); } }

  /** Искры летят от элемента к цели — «удар» передаёт жар в ядро рейтинга. */
  function flyTo(fromEl, toEl, count, color) {
    if (!fromEl || !toEl) return;
    const a = center(fromEl), b = center(toEl);
    const n = reduced ? 2 : Math.min(20, Math.max(6, count));
    for (let i = 0; i < n; i++) {
      parts.push({ sx: a.x + (Math.random() - 0.5) * 80, sy: a.y + (Math.random() - 0.5) * 20, x: a.x, y: a.y,
        target: b, wobble: (Math.random() - 0.5) * 120, size: 2 + Math.random() * 1.5,
        color: color || [COLORS.gold, COLORS.ember, COLORS.white][i % 3], born: performance.now() + i * 25, life: 900 + Math.random() * 300 });
    }
    kick();
    setTimeout(() => burst(b.x, b.y, { count: 10, power: 4 }), reduced ? 0 : 950);
  }

  // ================= Курсор: кольцо + точка, клик = вспышка =================
  if (!touch && !reduced) {
    document.body.classList.add('has-cursor');
    const ring = document.createElement('div'), dot = document.createElement('div');
    ring.className = 'cursor-ring'; dot.className = 'cursor-dot';
    document.body.append(ring, dot);
    let mx = innerWidth / 2, my = innerHeight / 2, rx = mx, ry = my;
    addEventListener('mousemove', e => { mx = e.clientX; my = e.clientY; dot.style.transform = `translate(${mx}px,${my}px)`; });
    (function follow() {
      rx += (mx - rx) * 0.2; ry += (my - ry) * 0.2;
      ring.style.transform = `translate(${rx}px,${ry}px)`;
      requestAnimationFrame(follow);
    })();
    const HOVER = 'a,button,select,input,textarea,label,.tile,.scroll-head,.star,.chip,[data-action]';
    addEventListener('mouseover', e => ring.classList.toggle('big', !!e.target.closest(HOVER)));
    addEventListener('mousedown', e => {
      ring.classList.add('press'); setTimeout(() => ring.classList.remove('press'), 180);
      burst(e.clientX, e.clientY, { count: 6, colors: [COLORS.lime], power: 3.5, size: 1.6 });
    });
    addEventListener('mouseleave', () => { ring.style.opacity = 0; dot.style.opacity = 0; });
    addEventListener('mouseenter', () => { ring.style.opacity = ''; dot.style.opacity = ''; });
  }

  // ================= Загрузчик «Forge Ignites» — один раз за сессию =================
  function loader() {
    let lit = false;
    try { lit = sessionStorage.getItem('forge-lit') === '1'; sessionStorage.setItem('forge-lit', '1'); } catch (e) { lit = true; }
    const el = document.getElementById('loader');
    if (!el) return;
    if (lit) { el.remove(); return; }
    el.hidden = false;
    setTimeout(() => el.classList.add('done'), reduced ? 300 : 2000);
    setTimeout(() => el.remove(), reduced ? 700 : 2600);
  }

  // ================= Ритуал публикации: трещина → вспышка → метеорит =================
  function ritual(sourceEl) {
    return new Promise(resolve => {
      play('hammer'); setTimeout(() => play('rumble'), 120);
      if (reduced) { resolve(); return; }
      const W = innerWidth, H = innerHeight, cx = W / 2, cy = H / 2;
      let paths = '';
      for (let i = 0; i < 9; i++) {
        let a = (i / 9) * Math.PI * 2 + Math.random() * 0.4, x = cx, y = cy, d = `M${cx} ${cy}`;
        const len = Math.max(W, H) * (0.45 + Math.random() * 0.3);
        for (let s = 0; s < 7; s++) {
          a += (Math.random() - 0.5) * 0.7;
          x += Math.cos(a) * len / 7; y += Math.sin(a) * len / 7; d += ` L${x.toFixed(0)} ${y.toFixed(0)}`;
        }
        paths += `<path d="${d}" pathLength="1"/>`;
      }
      const ov = document.createElement('div');
      ov.className = 'ritual';
      ov.innerHTML = `<svg viewBox="0 0 ${W} ${H}">${paths}</svg><div class="ritual-flash"></div>`;
      document.body.appendChild(ov);
      if (sourceEl) {
        const r = sourceEl.getBoundingClientRect();
        const m = sourceEl.cloneNode(true);
        m.classList.add('meteor');
        Object.assign(m.style, { left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' });
        setTimeout(() => { document.body.appendChild(m); requestAnimationFrame(() => m.classList.add('fly')); }, 700);
        setTimeout(() => m.remove(), 1700);
      }
      burst(cx, cy, { count: 30, power: 11 });
      setTimeout(() => { ov.remove(); resolve(); }, 1500);
    });
  }

  // ================= «Шёпот» ИИ: рукописная подсказка после 3 с бездействия =================
  let whisperSource = null, idleTimer = null, lastX = innerWidth / 2, lastY = innerHeight / 2;
  function scheduleWhisper() {
    clearTimeout(idleTimer);
    if (!whisperSource) return;
    idleTimer = setTimeout(() => {
      const text = whisperSource && whisperSource();
      if (!text) return;
      const w = document.createElement('div');
      w.className = 'whisper';
      w.textContent = text;
      w.style.left = Math.min(lastX + 22, innerWidth - 320) + 'px';
      w.style.top = Math.min(lastY + 22, innerHeight - 80) + 'px';
      document.body.appendChild(w);
      setTimeout(() => w.classList.add('out'), 3500);
      setTimeout(() => w.remove(), 4000);
    }, 3000);
  }
  ['mousemove', 'keydown', 'scroll'].forEach(ev => addEventListener(ev, e => {
    if (e.clientX !== undefined) { lastX = e.clientX; lastY = e.clientY; }
    scheduleWhisper();
  }, { passive: true }));
  function setWhisper(fn) { whisperSource = fn; scheduleWhisper(); }

  // ================= View Transitions =================
  // Если браузер не отрисовывает кадры (фоновая вкладка) и колбэк перехода задерживается —
  // страница всё равно обновится через 400 мс.
  function transition(update) {
    let done = false;
    const run = () => { if (!done) { done = true; update(); } };
    if (document.startViewTransition && !reduced) {
      try {
        const vt = document.startViewTransition(run);
        // Переход может быть пропущен (быстрая навигация) — это не ошибка.
        [vt.ready, vt.finished, vt.updateCallbackDone].forEach(p => p && p.catch(() => {}));
      } catch (e) { run(); }
      setTimeout(run, 400);
    } else run();
  }

  return {
    reduced, touch, COLORS, play, setMuted, isMuted: () => muted,
    burst, burstAt, flyTo, loader, ritual, setWhisper, transition,
  };
})();

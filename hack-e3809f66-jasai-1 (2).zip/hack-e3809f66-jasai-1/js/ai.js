﻿// AI-модуль: анализ полноты черновика, уточняющие вопросы, сборка карточки.
// Провайдеры по приоритету (js/ai-provider.js): Grok (xAI) → OpenAI → локальная эвристика без сети.
// Любой ответ модели проходит валидацию схемы и проверку «нет выдуманных фактов»;
// при ошибке используется локальный результат, а ошибка пишется в журнал.
window.AI = (function () {
  const S = window.Scoring;
  const tr = window.I18N.t;
  const CARD_KEYS = S.FIELDS.map(f => f.key);            // включая title
  const SCORED_KEYS = S.SCORED.map(f => f.key);

  // ---------- Промпты ----------
  const PROMPTS = {
    analyze: {
      system: [
        'Ты помощник, который помогает представителю бизнеса описать задачу для студенческих команд.',
        'Тебе дают черновик задачи (и, возможно, уже известные поля карточки).',
        'Шаг 1. Разнеси сведения из текста по полям карточки. Используй ТОЛЬКО факты из входного текста.',
        'Не добавляй цифры, сроки, технологии, названия, контакты и данные, которых нет во входе. Если сведений для поля нет — верни пустую строку.',
        'Шаг 2. Определи недостающие или слабые поля и задай от 3 до 5 уточняющих вопросов бизнесу — по одному на поле, начиная с самых весомых:',
        'data (20), context/need (20), expected_result (15), success_criteria (15), constraints (10), users (10), contact/interaction_format (10).',
        'Вопросы конкретные и привязаны к сути задачи. Не задавай вопросов про уже полностью описанные поля.',
        'Вопросы и подсказки пиши на языке интерфейса из поля lang входа: ru — русский, kk — казахский, en — английский.',
        'К каждому вопросу дай hint — короткий пример того, какой ответ повысит качество задачи (без выдуманных фактов о компании).',
        'Ответ — строго JSON по схеме, без пояснений.',
      ].join('\n'),
    },
    buildCard: {
      system: [
        'Ты собираешь карточку бизнес-задачи из черновика, известных полей и ответов бизнеса на уточняющие вопросы.',
        'Правила:',
        '- Используй только сведения из входа. Запрещено придумывать факты, цифры, сроки, контакты, технологии.',
        '- Можно переформулировать и сократить текст для ясности, сохраняя смысл и все цифры.',
        '- Ответ на вопрос о поле X помещай в поле X, дополняя уже известный текст, а не заменяя его.',
        '- Если по полю сведений нет — пустая строка.',
        '- title: короткое название (до 80 символов) из слов входа.',
        '- Пиши на языке исходного текста пользователя; не переводи его сведения.',
        'Ответ — строго JSON по схеме, без пояснений.',
      ].join('\n'),
    },
  };

  const fieldsSchema = {
    type: 'object',
    properties: Object.fromEntries(CARD_KEYS.map(k => [k, { type: 'string' }])),
    required: CARD_KEYS,
    additionalProperties: false,
  };
  const SCHEMAS = {
    analyze: {
      type: 'object',
      properties: {
        fields: fieldsSchema,
        questions: {
          type: 'array',
          items: {
            type: 'object',
            properties: { field: { type: 'string', enum: SCORED_KEYS }, question: { type: 'string' }, hint: { type: 'string' } },
            required: ['field', 'question', 'hint'],
            additionalProperties: false,
          },
        },
      },
      required: ['fields', 'questions'],
      additionalProperties: false,
    },
    buildCard: {
      type: 'object',
      properties: { card: fieldsSchema },
      required: ['card'],
      additionalProperties: false,
    },
  };

  // ---------- Локальная заглушка ----------
  // Порядок важен: предложение попадает в первое подходящее поле.
  const RULES = [
    ['contact', /(@|\+7|\+?\d{3}[\s-]?\d{3}[\s-]?\d{2}|t\.me|контакт|пишите|звоните|байланыс|contact)/i],
    ['interaction_format', /(созвон|встреч|раз в неделю|раз в две|еженедел|консультац|zoom|google meet|обратн\w* связ|на связи|апта сайын|аптасына|кездесу|қоңырау|weekly|meeting|call)/i],
    ['success_criteria', /(критери|успех|успешн|kpi|метрик|точност|\d+\s?%|считаем.*(успеш|готов)|табыс|дәлдік|success|accuracy|metric)/i],
    ['constraints', /(срок|дедлайн|за \d+ недел|месяц|бюджет|ограничен|nda|нельзя|без доступа|стек|только на|мерзім|шектеу|deadline|budget|within \d+|stack|constraint)/i],
    ['data', /(данн|выгрузк|excel|xlsx|csv|таблиц|баз[аеыу]|логи|архив|фото|пример|записи|записей|api|crm|мис|1с|1c|google sheets|дерек|кесте|экспорт|data|export|spreadsheet|database|records)/i],
    ['expected_result', /(хотим получить|на выходе|результат|прототип|дашборд|чат-бот|бот[а]?\b|mvp|приложени|сайт|отч[её]т|модел|нәтиже|қосымша|prototype|dashboard|chatbot|\bbot\b|app\b|report|model)/i],
    ['need', /(нужн|надо|хотим|хотелось|необходимо|требуется|сократить|снизить|автоматизир|қажет|керек|келеді|азайту|we need|we want|need to|want to|should|reduce|improve)/i],
    ['users', /(пользовател|будут пользоваться|для (сотрудник|менеджер|клиент|оператор|покупател|кассир|бухгалтер|водител|курьер|врач|учител|студент|агроном|куратор|пациент|диспетчер)|пайдаланушы|пайдаланады|users|will be used by)/i],
  ];
  // Предложения, не подошедшие ни под одно правило (описание ситуации), идут в «Контекст».

  function splitSentences(text) {
    return String(text || '')
      .replace(/\s+/g, ' ')
      .split(/(?<=[.!?;])\s+|\n+/)
      .map(s => s.trim())
      .filter(Boolean);
  }

  function emptyCard() {
    return Object.fromEntries(CARD_KEYS.map(k => [k, '']));
  }

  function makeTitle(text) {
    const first = splitSentences(text)[0] || '';
    const clean = first.replace(/[.!?;]+$/, '');
    if (clean.length <= 70) return clean;
    return clean.split(' ').slice(0, 8).join(' ') + '…';
  }

  function extractLocal(draft, known) {
    const out = { ...emptyCard(), ...(known || {}) };
    if (known && Object.values(known).some(v => String(v || '').trim())) return out; // уточнение готовой карточки
    for (const sentence of splitSentences(draft)) {
      const rule = RULES.find(([, re]) => re.test(sentence));
      const key = rule ? rule[0] : 'context';
      out[key] = out[key] ? out[key] + ' ' + sentence : sentence;
    }
    // «Хотим чат-бота…» — это и результат, и потребность: переносим ту же фразу пользователя, ничего не добавляя.
    const needRule = RULES.find(([k]) => k === 'need')[1];
    if (!out.need) out.need = splitSentences(draft).find(s => needRule.test(s)) || '';
    out.title = out.title || makeTitle(draft);
    return out;
  }

  function questionsLocal(card) {
    const sc = S.score(card);
    const qs = sc.missing.slice(0, 5).map(m => {
      const f = S.byKey[m.key];
      const prefix = m.status === 'empty' ? '' : tr('q.refine');
      // kind позволяет интерфейсу пересобрать текст вопроса при смене языка.
      return { field: m.key, question: prefix + f.question, hint: f.hint, kind: m.status === 'empty' ? 'ask' : 'refine' };
    });
    // Минимум 3 вопроса, даже если карточка почти полная.
    const extra = S.SCORED.slice().sort((a, b) => b.weight - a.weight);
    for (const f of extra) {
      if (qs.length >= 3) break;
      if (!qs.some(q => q.field === f.key)) qs.push({ field: f.key, question: tr('q.more') + f.question, hint: f.hint, kind: 'more' });
    }
    return qs;
  }

  function analyzeLocal(input) {
    const fields = extractLocal(input.draft, input.known);
    return { fields, questions: questionsLocal(fields) };
  }

  function capitalize(s) { return s ? s[0].toUpperCase() + s.slice(1) : s; }

  function buildCardLocal(input) {
    const card = { ...emptyCard(), ...input.fields };
    for (const a of input.answers) {
      const ans = String(a.answer || '').trim();
      if (!ans || !CARD_KEYS.includes(a.field)) continue;
      const sentence = /[.!?]$/.test(ans) ? capitalize(ans) : capitalize(ans) + '.';
      card[a.field] = card[a.field] ? card[a.field].replace(/\s*$/, '') + (/[.!?]$/.test(card[a.field].trim()) ? ' ' : '. ') + sentence : sentence;
    }
    if (!card.title) card.title = makeTitle(input.draft);
    return { card };
  }

  // ---------- Валидация ответа модели ----------
  function parseJson(raw) {
    const text = String(raw || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/```$/, '').trim();
    try { return { ok: true, value: JSON.parse(text) }; }
    catch (e) { return { ok: false, error: tr('v.json', e.message) }; }
  }

  function validateFields(obj, errors, path) {
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) { errors.push(tr('v.object', path)); return; }
    for (const k of CARD_KEYS) {
      if (!(k in obj)) errors.push(tr('v.missing', `${path}.${k}`));
      else if (typeof obj[k] !== 'string') errors.push(tr('v.string', `${path}.${k}`));
    }
    for (const k of Object.keys(obj)) if (!CARD_KEYS.includes(k)) errors.push(tr('v.unknown', `${path}.${k}`));
  }

  function validate(kind, value) {
    const errors = [];
    if (!value || typeof value !== 'object') return [tr('v.root')];
    if (kind === 'analyze') {
      validateFields(value.fields, errors, 'fields');
      if (!Array.isArray(value.questions)) errors.push(tr('v.qarray'));
      else {
        value.questions.forEach((q, i) => {
          if (!q || typeof q.question !== 'string' || !q.question.trim()) errors.push(tr('v.qempty', i));
          if (!q || !SCORED_KEYS.includes(q.field)) errors.push(tr('v.qfield', i, q && q.field));
          if (q && q.hint !== undefined && typeof q.hint !== 'string') errors.push(tr('v.hint', i));
        });
      }
    } else {
      validateFields(value.card, errors, 'card');
    }
    return errors;
  }

  // ---------- Проверка «ИИ не добавляет фактов» ----------
  const stem = w => w.slice(0, 5);
  function words(text) {
    return (String(text || '').toLowerCase().match(/[a-zа-яёәғқңөұүһі]{4,}/gi) || []).map(stem);
  }
  function numbers(text) {
    return String(text || '').match(/\d+(?:[.,]\d+)?/g) || [];
  }

  // Возвращает список полей, где модель, вероятно, добавила сведения не из входа.
  function groundingCheck(card, sourceText) {
    const srcWords = new Set(words(sourceText));
    const srcNums = new Set(numbers(sourceText));
    const issues = [];
    for (const k of CARD_KEYS) {
      const v = card[k];
      if (!v) continue;
      const newNums = numbers(v).filter(n => !srcNums.has(n));
      const ws = words(v);
      const novel = ws.filter(w => !srcWords.has(w));
      const novelShare = ws.length ? novel.length / ws.length : 0;
      if (newNums.length) issues.push({ field: k, reason: tr('v.nums', newNums.join(', ')) });
      else if (ws.length >= 4 && novelShare > 0.5) issues.push({ field: k, reason: tr('v.words', Math.round(novelShare * 100)) });
    }
    return issues;
  }

  // ---------- OpenAI-совместимый API: Grok (xAI) и OpenAI ----------
  // Chat Completions + structured outputs (json_schema, strict). Без SDK: проект запускается без npm.
  const DEFAULT_MODEL = 'gpt-4o-mini';
  // provider — из AIProvider.get(): Grok (xAI) и OpenAI принимают одинаковый запрос Chat Completions.
  async function callOpenAI(provider, kind, input) {
    // Grok дополнительно получает схему текстом в промпте — на случай, если модель не поддерживает json_schema.
    const system = provider.name === 'grok' ? PROMPTS[kind].system + '\nJSON Schema:\n' + JSON.stringify(SCHEMAS[kind]) : PROMPTS[kind].system;
    const res = await fetch(provider.url, {
      // Ответ 401 от OpenAI приходит без CORS-заголовка, поэтому браузер видит его как сетевую ошибку.
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + provider.apiKey },
      body: JSON.stringify({
        model: provider.model,
        temperature: 0,
        messages: [
          { role: 'system', content: system },
          { role: 'user', content: JSON.stringify(input, null, 2) },
        ],
        response_format: { type: 'json_schema', json_schema: { name: kind, strict: true, schema: SCHEMAS[kind] } },
      }),
    }).catch(e => { throw new Error(tr('v.network', e.message)); });
    const body = await res.json().catch(() => null);
    if (!res.ok) throw new Error(tr('v.http', res.status, body && body.error ? body.error.message : tr('v.noAnswer')));
    const choice = body && body.choices && body.choices[0];
    if (!choice) throw new Error(tr('v.noChoices'));
    if (choice.message.refusal) throw new Error(tr('v.refusal', choice.message.refusal));
    if (choice.finish_reason === 'length') throw new Error(tr('v.length'));
    return choice.message.content;
  }

  function sourceOf(input) {
    const parts = [input.draft || ''];
    if (input.known) parts.push(Object.values(input.known).join(' '));
    if (input.fields) parts.push(Object.values(input.fields).join(' '));
    if (input.answers) parts.push(input.answers.map(a => a.answer).join(' '));
    return parts.join(' ');
  }

  // Обработка сырого ответа: парсинг → валидация → проверка фактов → слияние с локальным результатом.
  function processRaw(kind, input, raw, log) {
    const local = kind === 'analyze' ? analyzeLocal(input) : buildCardLocal(input);
    const parsed = parseJson(raw);
    if (!parsed.ok) { log.errors.push(parsed.error); log.fallback = true; return local; }
    log.parsed = parsed.value;
    const errs = validate(kind, parsed.value);
    if (errs.length) { log.errors.push(...errs); log.fallback = true; return local; }

    const result = JSON.parse(JSON.stringify(parsed.value));
    const card = kind === 'analyze' ? result.fields : result.card;
    const localCard = kind === 'analyze' ? local.fields : local.card;
    const issues = groundingCheck(card, sourceOf(input));
    for (const is of issues) {
      card[is.field] = localCard[is.field];
      log.grounding.push(tr('v.replaced', is.field, is.reason));
    }
    if (kind === 'analyze') {
      const seen = new Set();
      result.questions = result.questions.filter(q => !seen.has(q.field) && seen.add(q.field)).slice(0, 5)
        .map(q => ({ ...q, hint: q.hint || S.byKey[q.field].hint }));
      if (result.questions.length < 3) {
        log.errors.push(tr('v.fewq', result.questions.length));
        for (const q of questionsLocal(card)) {
          if (result.questions.length >= 3) break;
          if (!result.questions.some(x => x.field === q.field)) result.questions.push(q);
        }
      }
    }
    return result;
  }

  async function run(kind, input, settings, onLog) {
    // Провайдер по приоритету: Grok (xAI) → OpenAI → fallback-эвристика.
    const provider = window.AIProvider.get(settings);
    const useApi = provider.name !== 'fallback';
    console.log('[AI] Provider:', provider.label);
    const log = {
      at: Date.now(), op: kind, mode: provider.name,
      model: useApi ? `${provider.label} · ${provider.model}` : 'local-rules',
      system: PROMPTS[kind].system, input, raw: null, parsed: null,
      errors: [], grounding: [], fallback: false,
    };
    let result;
    if (useApi) {
      try {
        log.raw = await callOpenAI(provider, kind, input);
        result = processRaw(kind, input, log.raw, log);
      } catch (e) {
        log.errors.push(e.message);
        log.fallback = true;
        result = kind === 'analyze' ? analyzeLocal(input) : buildCardLocal(input);
      }
    } else {
      result = kind === 'analyze' ? analyzeLocal(input) : buildCardLocal(input);
      log.parsed = result;
    }
    log.output = result;
    // Лог каждого вызова в консоль браузера.
    console.log('[AI]', kind, log.model, log.fallback ? 'FALLBACK' : 'ok', { errors: log.errors, grounding: log.grounding, input, output: result });
    if (onLog) onLog(log);
    return { result, log };
  }

  // ---------- Рекомендации задач студентам ----------
  // Совпадение интересов/навыков команды с текстом задачи. Каталог не ограничивает — только подсказка.
  function recommend(team, tasks) {
    const tags = [...team.interests, ...team.skills, ...team.tech].map(t => t.toLowerCase());
    return tasks
      .filter(t => t.score >= 40)
      .map(t => {
        const text = (t.industry + ' ' + Object.values(t.card).join(' ')).toLowerCase();
        const hits = tags.filter(tag => tag.split(/\s+/).some(w => w.length >= 3 && text.includes(w.slice(0, Math.max(3, Math.min(6, w.length - 1))))));
        return { task: t, hits: [...new Set(hits)] };
      })
      .filter(r => r.hits.length)
      .sort((a, b) => (b.hits.length - a.hits.length) || (b.task.score - a.task.score));
  }

  return {
    PROMPTS, SCHEMAS, DEFAULT_MODEL, run, processRaw, validate, parseJson, groundingCheck,
    analyzeLocal, buildCardLocal, questionsLocal, extractLocal, recommend, emptyCard,
  };
})();

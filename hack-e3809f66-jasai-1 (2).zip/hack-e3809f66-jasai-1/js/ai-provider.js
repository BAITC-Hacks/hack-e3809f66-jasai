// Выбор AI-провайдера по приоритету: Grok (xAI) → OpenAI → fallback-эвристика.
// Изолированный модуль: не знает про промпты и валидацию, только отвечает, куда отправить запрос.
// Grok API совместим с OpenAI Chat Completions — отличаются только адрес, ключ и модель.
// Ключи вводятся в разделе «ИИ» и хранятся только в localStorage этого браузера (в коде ключей нет).
window.AIProvider = (function () {
  const PROVIDERS = {
    grok: { label: 'Grok (xAI)', url: 'https://api.x.ai/v1/chat/completions', defaultModel: 'grok-3-mini', keyName: 'XAI_API_KEY' },
    openai: { label: 'OpenAI', url: 'https://api.openai.com/v1/chat/completions', defaultModel: 'gpt-4o-mini', keyName: 'OPENAI_API_KEY' },
  };
  const has = v => typeof v === 'string' && v.trim() !== '';

  /**
   * Возвращает провайдера для настроек:
   *   mode 'local'            → всегда fallback (принудительная эвристика);
   *   иначе, если есть ключ xAI    → Grok;
   *   иначе, если есть ключ OpenAI → OpenAI;
   *   иначе                        → fallback.
   * Поле settings.apiKey — ключ OpenAI (сохранено для совместимости с прежними настройками).
   */
  function get(settings) {
    const s = settings || {};
    if (s.mode === 'local') return { name: 'fallback', label: 'fallback', model: 'local-rules' };
    if (has(s.xaiKey)) {
      const p = PROVIDERS.grok;
      return { name: 'grok', label: p.label, url: p.url, apiKey: s.xaiKey.trim(), model: (s.xaiModel || '').trim() || p.defaultModel };
    }
    if (has(s.apiKey)) {
      const p = PROVIDERS.openai;
      return { name: 'openai', label: p.label, url: p.url, apiKey: s.apiKey.trim(), model: (s.model || '').trim() || p.defaultModel };
    }
    return { name: 'fallback', label: 'fallback', model: 'local-rules' };
  }

  return { PROVIDERS, get };
})();

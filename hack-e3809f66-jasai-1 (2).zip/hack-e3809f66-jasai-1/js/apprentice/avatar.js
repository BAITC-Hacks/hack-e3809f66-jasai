// Компонент аватара «Кот-кузнец»: рыжий кот в кожаном фартуке с молотом на плече, светящиеся глаза.
// Не содержит логики ИИ — только отражает состояние (idle / thinking / ready / error) и показывает реплику.
window.Apprentice = (function () {
  const C = window.APPRENTICE_CONFIG;
  let uid = 0;

  function svg() {
    const id = 'apc' + (++uid);
    return `<svg class="ap-svg" viewBox="0 0 100 100" aria-hidden="true">
      <defs>
        <radialGradient id="${id}h"><stop offset="0" stop-color="#FF6B1A" stop-opacity=".55"/><stop offset=".6" stop-color="#FF6B1A" stop-opacity=".15"/><stop offset="1" stop-color="#FF6B1A" stop-opacity="0"/></radialGradient>
        <linearGradient id="${id}f" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFB25E"/><stop offset="1" stop-color="#E07A2E"/></linearGradient>
        <filter id="${id}g" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="1.4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
      </defs>
      <circle class="ap-halo" cx="50" cy="56" r="47" fill="url(#${id}h)"/>
      <g class="ap-body">
        <path class="ap-tail" d="M70 92 Q94 86 90 62 Q88 52 80 54"/>
        <path class="ap-fur" fill="url(#${id}f)" d="M26 100 Q24 70 50 64 Q76 70 74 100 Z"/>
        <path class="ap-apron" d="M35 72 L65 72 L69 100 L31 100 Z"/>
        <path class="ap-strap" d="M35 72 L40 62 M65 72 L60 62"/>
        <rect class="ap-pocket" x="43" y="84" width="14" height="9" rx="2"/>
        <g class="ap-rune"><circle cx="50" cy="79" r="4"/><path d="M50 75.5 L53.5 81.5 L46.5 81.5 Z"/></g>
        <g class="ap-head">
          <path class="ap-ear" fill="url(#${id}f)" d="M31 38 L33 13 L48 28 Z"/>
          <path class="ap-ear" fill="url(#${id}f)" d="M69 38 L67 13 L52 28 Z"/>
          <path class="ap-ear-in" d="M34 33 L35.5 19 L44 28 Z"/><path class="ap-ear-in" d="M66 33 L64.5 19 L56 28 Z"/>
          <ellipse class="ap-face" fill="url(#${id}f)" cx="50" cy="44" rx="22" ry="19"/>
          <path class="ap-stripe" d="M50 27 L50 33 M44 28 L45.5 33 M56 28 L54.5 33"/>
          <ellipse class="ap-muzzle" cx="50" cy="53" rx="10" ry="6.5"/>
          <path class="ap-nose" d="M47.5 49.5 L52.5 49.5 L50 52.5 Z"/>
          <path class="ap-mouth" d="M50 52.5 Q48 56 45.5 54.5 M50 52.5 Q52 56 54.5 54.5"/>
          <path class="ap-whisker" d="M40 52 L25 49 M40 55 L25 56 M60 52 L75 49 M60 55 L75 56"/>
          <g class="ap-eyes" filter="url(#${id}g)">
            <ellipse class="ap-eye" cx="41.5" cy="42" rx="4.6" ry="5.2"/><ellipse class="ap-eye" cx="58.5" cy="42" rx="4.6" ry="5.2"/>
            <ellipse class="ap-pupil" cx="41.5" cy="42" rx="1.3" ry="3.9"/><ellipse class="ap-pupil" cx="58.5" cy="42" rx="1.3" ry="3.9"/>
          </g>
        </g>
      </g>
      <g class="ap-hammer">
        <path class="ap-handle" d="M69 80 L86 40"/>
        <rect class="ap-head-h" x="76" y="27" width="22" height="12" rx="2.5" transform="rotate(23 87 33)"/>
        <circle class="ap-paw" cx="70" cy="78" r="5"/>
        <g class="ap-sparks"><circle cx="96" cy="20" r="1.6"/><circle cx="99" cy="30" r="1.2"/><circle cx="88" cy="16" r="1.3"/><circle cx="98" cy="24" r="1"/></g>
      </g>
    </svg>`;
  }

  /** Создаёт элемент аватара. opts: { state, size, message, showMessage, position, className }. */
  function create(opts) {
    const o = Object.assign({ state: 'idle', size: 'md', showMessage: true, position: 'right' }, opts);
    const el = document.createElement('div');
    el.className = `apprentice ap-${o.size} ap-pos-${o.position} ${o.className || ''}`;
    el.style.setProperty('--ap-size', (C.sizes[o.size] || C.sizes.md) + 'px');
    // Случайный интервал моргания 4–7 с.
    el.style.setProperty('--ap-blink', (C.blinkMinMs + Math.random() * (C.blinkMaxMs - C.blinkMinMs)).toFixed(0) + 'ms');
    el.innerHTML = `<div class="ap-figure">${svg()}</div><div class="ap-bubble" role="status" aria-live="polite"><small class="ap-name"></small><span class="ap-text"></span></div>`;
    update(el, o);
    return el;
  }

  /** Обновляет состояние и реплику; при переходе в ready — несколько искр из молота. */
  function update(el, o) {
    const prev = el.dataset.state;
    if (o.state && o.state !== prev) {
      C.states.forEach(s => el.classList.remove('ap-' + s));
      el.classList.add('ap-' + o.state);
      el.dataset.state = o.state;
      if (o.state === 'ready' && prev && window.FX && el.isConnected) {
        window.FX.burstAt(el.querySelector('.ap-head-h'), { count: C.readySparks, colors: ['#C8FF3D', '#FFE066'], power: 3, size: 1.4 });
      }
    }
    if (o.name !== undefined) el.querySelector('.ap-name').textContent = o.name;
    if (o.message !== undefined) {
      const t = el.querySelector('.ap-text');
      if (t.textContent !== o.message) {
        t.textContent = o.message;
        const b = el.querySelector('.ap-bubble');
        b.classList.remove('ap-pop'); void b.offsetWidth; b.classList.add('ap-pop');
      }
    }
    const show = o.showMessage !== false && !!el.querySelector('.ap-text').textContent;
    el.classList.toggle('ap-silent', !show);
  }

  return { create, update };
})();

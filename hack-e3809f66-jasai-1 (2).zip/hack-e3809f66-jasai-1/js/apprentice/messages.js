﻿// Реплики аватара «Кот-кузнец» (подмастерье ИИ) на трёх языках.
// Немногословный (5–12 слов), уважительный («мастер»), спокойный. Не выдумывает фактов:
// числа в репликах (пробелы, баллы) берутся из того, что уже показывает интерфейс.
window.APPRENTICE_MESSAGES = (function () {
  const ruPl = (n, f) => { const a = n % 10, b = n % 100; return a === 1 && b !== 11 ? f[0] : a >= 2 && a <= 4 && (b < 10 || b >= 20) ? f[1] : f[2]; };

  return {
    ru: {
      meta: { name: 'Кот-кузнец' },
      step1: {
        idle: 'Начни с главного, мастер. Что не так?',
        minChars: 'Ещё пару строк — и начнём ковать.',
        typing: 'Вижу, дело серьёзное. Продолжай, мастер.',
        ready: 'Достаточно металла. Готов ковать?',
      },
      step2: {
        thinking: 'Раздуваю горн, изучаю описание…',
        foundGaps: p => `Нашёл ${p.count} ${ruPl(p.count, ['пробел', 'пробела', 'пробелов'])}. Ответь — задача станет сильнее.`,
        userAnswered: p => `Хороший удар, мастер. +${p.points} ${ruPl(p.points, ['балл', 'балла', 'баллов'])}.`,
        userSkipped: 'Пропустил — не страшно. Можно вернуться позже.',
        allDone: 'Всё, что нужно. Собирай карточку, мастер.',
      },
      step3: {
        building: 'Собираю клинок из твоих слов…',
        built: 'Вот что получилось. Проверь каждое слово, мастер.',
        ratingLow: 'Пока черновик. Добавь деталей, мастер.',
        ratingMid: 'Уже рабочая. Ещё пара ударов.',
        ratingHigh: 'Готовая. Осталось чуть-чуть, мастер.',
        ratingMax: 'Идеальный сплав. Ты мастер.',
      },
      publish: {
        confirm: 'Печать стоит. Публиковать решаешь ты, мастер.',
        publishing: 'Отправляю клинок в каталог…',
        published: 'Задача ушла в каталог, мастер.',
      },
      error: {
        noApi: 'Связь с горном потеряна. Работаю по памяти.',
        fallback: 'Ответ модели отброшен. Работаю по памяти, продолжаем.',
      },
      bids: {
        mustChooseManually: 'Я не выбираю за тебя — это твоя кузница.',
      },
      floating: {
        idle: 'Если что — я рядом, мастер.',
        afterInactivity: 'Задумался? Я подожду.',
      },
    },

    kk: {
      meta: { name: 'Ұста мысық' },
      step1: {
        idle: 'Ең маңыздысынан баста, шебер. Не мазалайды?',
        minChars: 'Тағы бір-екі жол — сосын соғамыз.',
        typing: 'Іс байыпты екен. Жалғастыр, шебер.',
        ready: 'Металл жеткілікті. Соғуға дайынсың ба?',
      },
      step2: {
        thinking: 'Көрікті үрлеп, сипаттаманы зерттеп жатырмын…',
        foundGaps: p => `${p.count} олқылық таптым. Жауап бер — тапсырма күшейеді.`,
        userAnswered: p => `Жақсы соққы, шебер. +${p.points} ұпай.`,
        userSkipped: 'Өткізіп жібердің — оқасы жоқ. Кейін оралуға болады.',
        allDone: 'Керегінің бәрі бар. Карточканы құрастыр, шебер.',
      },
      step3: {
        building: 'Сенің сөздеріңнен қылыш құрастырып жатырмын…',
        built: 'Міне, не шықты. Әр сөзді тексер, шебер.',
        ratingLow: 'Әзірге нобай. Толығырақ жаз, шебер.',
        ratingMid: 'Жұмысқа жарамды. Тағы бір-екі соққы.',
        ratingHigh: 'Дайын. Сәл ғана қалды, шебер.',
        ratingMax: 'Мінсіз қорытпа. Сен нағыз шеберсің.',
      },
      publish: {
        confirm: 'Мөр басылды. Жариялауды өзің шешесің, шебер.',
        publishing: 'Қылышты каталогқа жіберіп жатырмын…',
        published: 'Тапсырма каталогқа кетті, шебер.',
      },
      error: {
        noApi: 'Көрікпен байланыс үзілді. Жадым бойынша істеймін.',
        fallback: 'Модель жауабы қабылданбады. Жадым бойынша жалғастырамыз.',
      },
      bids: {
        mustChooseManually: 'Мен сен үшін таңдамаймын — бұл сенің ұстаханаң.',
      },
      floating: {
        idle: 'Керек болсам — осындамын, шебер.',
        afterInactivity: 'Ойланып қалдың ба? Мен күтемін.',
      },
    },

    en: {
      meta: { name: 'Smith Cat' },
      step1: {
        idle: 'Start with the main thing, master. What’s wrong?',
        minChars: 'A couple more lines and we start forging.',
        typing: 'I see, this is serious. Go on, master.',
        ready: 'Enough metal. Ready to forge?',
      },
      step2: {
        thinking: 'Stoking the forge, reading your description…',
        foundGaps: p => `Found ${p.count} ${p.count === 1 ? 'gap' : 'gaps'}. Answer and the task grows stronger.`,
        userAnswered: p => `Good strike, master. +${p.points} ${p.points === 1 ? 'point' : 'points'}.`,
        userSkipped: 'Skipped it — no worries. You can come back later.',
        allDone: 'That’s all we need. Assemble the card, master.',
      },
      step3: {
        building: 'Forging a blade from your words…',
        built: 'Here it is. Check every word, master.',
        ratingLow: 'Still a draft. Add some details, master.',
        ratingMid: 'Workable already. A few more strikes.',
        ratingHigh: 'Ready. Just a little more, master.',
        ratingMax: 'A perfect alloy. You are a master.',
      },
      publish: {
        confirm: 'Sealed. Publishing is your call, master.',
        publishing: 'Sending the blade to the catalog…',
        published: 'The task is in the catalog, master.',
      },
      error: {
        noApi: 'Lost contact with the forge. Working from memory.',
        fallback: 'Model response discarded. Working from memory, carry on.',
      },
      bids: {
        mustChooseManually: 'I don’t choose for you — this is your forge.',
      },
      floating: {
        idle: 'I’m close by if you need me, master.',
        afterInactivity: 'Lost in thought? I’ll wait.',
      },
    },
  };
})();

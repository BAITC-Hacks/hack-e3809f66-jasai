﻿// Контроллер аватара «Кот-кузнец». Существующий код не вызывает и не меняет:
// наблюдает за DOM (MutationObserver) и событиями ввода и по ним выбирает состояние и реплику.
//   • Шаги кузницы 1–3 — аватар над формой (размер lg).
//   • Свитки контрактов у владельца задачи — напоминание, что выбирает только бизнес.
//   • Плавающий кот в углу — всегда виден; говорит при публикации, по клику и после 5 с бездействия.
// Если удалить папку js/apprentice и строки подключения в index.html, проект работает как раньше.
(function () {
  const M = window.APPRENTICE_MESSAGES, C = window.APPRENTICE_CONFIG, A = window.Apprentice;
  const app = document.getElementById('app');
  if (!M || !C || !A || !app) return;

  // ---------- Реплики на текущем языке (из существующего переключателя I18N) ----------
  const lang = () => (window.I18N && M[window.I18N.getLang()] ? window.I18N.getLang() : 'ru');
  function say(path, params) {
    const [g, k] = path.split('.');
    const v = (M[lang()][g] || {})[k] !== undefined ? M[lang()][g][k] : M.ru[g][k];
    return typeof v === 'function' ? v(params || {}) : v;
  }

  // ---------- Чтение состояния интерфейса (только чтение) ----------
  const q = s => app.querySelector(s);
  function context() {
    if (q('.anvil-wait')) return 'thinking';
    if (q('.qcard')) return 'step2';
    if (q('[data-f="title"]')) return 'step3';
    if (q('#w-draft')) return 'step1';
    if (q('.scrolls-panel')) return 'bids';
    return null;
  }
  const score = () => { const n = app.querySelector('#scene .num'); return n ? +n.textContent : null; };
  // Fallback ИИ виден в бейдже [AI]: предупреждение с пометкой «fallback».
  const aiFailed = () => { const w = q('.aibadge .warn'); return !!(w && /fallback/i.test(w.textContent)); };
  const aiNoApi = () => { const w = q('.aibadge .warn'); return !!(w && /(HTTP|fetch|network|сеть|интернет|кілт|connection)/i.test(w.textContent)); };
  function ratingKey(s) {
    if (s >= C.levels.priority) return 'step3.ratingMax';
    if (s >= C.levels.ready) return 'step3.ratingHigh';
    if (s >= C.levels.working) return 'step3.ratingMid';
    return 'step3.ratingLow';
  }

  // ---------- Встроенный аватар ----------
  let ctx = null, prevCtx = null;
  let cur = { state: 'idle', key: 'step1.idle', params: null };   // ключ хранится, текст берётся на текущем языке
  let inline = null;

  function defaultsFor(c) {
    if (c === 'thinking') return { state: 'thinking', key: prevCtx === 'step2' ? 'step3.building' : 'step2.thinking' };
    if (c === 'step1') return { state: 'idle', key: 'step1.idle' };
    if (c === 'step2') {
      if (aiFailed()) return { state: 'error', key: aiNoApi() ? 'error.noApi' : 'error.fallback' };
      return { state: 'ready', key: 'step2.foundGaps', params: { count: app.querySelectorAll('.qcard').length } };
    }
    if (c === 'step3') {
      if (aiFailed()) return { state: 'error', key: aiNoApi() ? 'error.noApi' : 'error.fallback' };
      if (q('.scene .note.ok, #scene .note.ok')) return { state: 'ready', key: 'publish.confirm' };
      return { state: 'ready', key: 'step3.built' };
    }
    if (c === 'bids') return { state: 'idle', key: 'bids.mustChooseManually' };
    return null;
  }

  function mountPoint(c) {
    if (c === 'thinking') return { parent: q('.anvil-wait'), before: q('.anvil-wait .spinner') };
    if (c === 'bids') { const h = q('.scrolls-panel .contract-head'); return h && { parent: h.parentNode, before: h.nextSibling }; }
    const main = q('.forge-main');
    return main && { parent: main, before: main.firstChild };
  }

  function render() {
    const text = say(cur.key, cur.params);
    if (!inline) inline = A.create({ size: 'lg', position: 'right', className: 'ap-inline' });
    A.update(inline, { state: cur.state, message: text, name: say('meta.name') });
  }

  let wasSealed = false;
  function sync() {
    // Опубликованная задача приземлилась в каталоге — сообщает плавающий помощник.
    const landed = q('.tile.landed');
    if (landed && landed.dataset.tid !== lastLanded) { lastLanded = landed.dataset.tid; floatEvent('publish.published', 'ready'); }

    const c = context();
    const sealed = c === 'step3' && !!q('#scene .note.ok');   // карточка подтверждена, изменений нет
    if (c !== ctx) {
      prevCtx = ctx; ctx = c;
      const d = defaultsFor(c);
      if (d) cur = { params: null, ...d };
    } else if (sealed && !wasSealed) {
      cur = { state: 'ready', key: 'publish.confirm' };          // печать поставлена — публикация за мастером
    } else if ((c === 'step2' || c === 'step3') && aiFailed() && cur.state !== 'error') {
      cur = { state: 'error', key: aiNoApi() ? 'error.noApi' : 'error.fallback' };
    }
    wasSealed = sealed;
    if (!c) { if (inline && inline.isConnected) inline.remove(); updateAway(); return; }
    render();
    const mp = mountPoint(c);
    if (mp && mp.parent && inline.parentNode !== mp.parent) mp.parent.insertBefore(inline, mp.before || null);
    updateAway();
  }

  // Реакции на ввод — только чтение значений полей.
  let before = null;
  app.addEventListener('focusin', e => { if (e.target.matches('[data-q]')) before = score(); });
  app.addEventListener('input', e => {
    const t = e.target;
    if (t.id === 'w-draft') {
      const n = t.value.trim().length;
      cur = { state: 'idle', key: n === 0 ? 'step1.idle' : n < 20 ? 'step1.minChars' : n < 80 ? 'step1.typing' : 'step1.ready' };
      if (n >= 80) cur.state = 'ready';
      render();
    }
    // Обработчик кузницы подключён раньше и уже обновил ядро рейтинга — читаем актуальное значение.
    if (t.matches('[data-f]')) {
      const s = score();
      if (s !== null) { cur = { state: 'ready', key: ratingKey(s) }; render(); }
    }
  });
  app.addEventListener('change', e => {
    const t = e.target;
    if (!t.matches('[data-q]')) return;
    const all = [...app.querySelectorAll('[data-q]')];
    const answered = all.filter(x => x.value.trim()).length;
    const gain = before === null ? 0 : (score() || 0) - before;
    if (!t.value.trim()) cur = { state: 'idle', key: 'step2.userSkipped' };        // ответ стёрли — не страшно
    else if (answered === all.length) cur = { state: 'ready', key: 'step2.allDone' };
    else if (gain > 0) cur = { state: 'ready', key: 'step2.userAnswered', params: { points: gain } };
    else cur = { state: 'idle', key: 'step2.foundGaps', params: { count: all.length - answered } };
    render();
  });

  // ---------- Плавающий кот ----------
  // Кот всегда сидит в левом нижнем углу (прячется, только когда такой же кот уже стоит над формой).
  // Реплика появляется по событиям, по клику на кота и после 5 с бездействия; исчезает при активности.
  const floatWrap = document.createElement('div');
  floatWrap.className = 'ap-floating';
  const floating = A.create({ size: 'md', position: 'right' });
  floatWrap.appendChild(floating);
  document.body.appendChild(floatWrap);
  let idleTimer = null, hideTimer = null, eventUntil = 0, shownOnce = false, lastLanded = null;

  function updateAway() {
    const busy = !!document.getElementById('loader') || (inline && inline.isConnected && Date.now() > eventUntil);
    floatWrap.classList.toggle('away', busy);
  }
  const blocked = () => document.getElementById('demo-bar') || document.getElementById('loader') || (inline && inline.isConnected);
  function showFloating(key, state, ms) {
    A.update(floating, { state, message: say(key), name: say('meta.name') });
    floatWrap.dataset.key = key;
    floatWrap.classList.add('talk');
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => { floatWrap.classList.remove('talk'); A.update(floating, { state: 'idle' }); updateAway(); }, ms);
  }
  function floatEvent(key, state) {
    eventUntil = Date.now() + C.eventShowMs;
    updateAway();
    showFloating(key, state, C.eventShowMs);
  }
  function scheduleIdle() {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => {
      if (blocked()) return scheduleIdle();
      showFloating(shownOnce ? 'floating.afterInactivity' : 'floating.idle', 'idle', C.floatingShowMs);
      shownOnce = true;                                // одна реплика на один период бездействия
    }, C.floatingIdleMs);
  }
  ['mousemove', 'keydown', 'scroll', 'pointerdown'].forEach(ev => addEventListener(ev, e => {
    if (e.target && e.target.closest && e.target.closest('.ap-floating')) return;   // клик по коту — не «активность»
    if (Date.now() > eventUntil) floatWrap.classList.remove('talk');
    scheduleIdle();
  }, { passive: true }));
  // Клик по коту — он отзывается подсказкой.
  floating.querySelector('.ap-figure').addEventListener('click', () => {
    if (window.FX) { window.FX.play('spark'); window.FX.burstAt(floating.querySelector('.ap-head-h'), { count: 5, colors: ['#FFB25E', '#FFE066'], power: 3, size: 1.3 }); }
    showFloating('floating.idle', 'ready', C.floatingShowMs);
  });
  scheduleIdle();

  // Публикация: ритуал трещины появляется в <body>; загрузчик исчезает из <body>.
  new MutationObserver(muts => {
    for (const m of muts) for (const n of m.addedNodes) {
      if (n.classList && n.classList.contains('ritual')) floatEvent('publish.publishing', 'thinking');
    }
    updateAway();
  }).observe(document.body, { childList: true });
  updateAway();

  // Смена языка перерисовывает шапку — обновляем текст плавающего помощника.
  document.getElementById('header').addEventListener('click', e => {
    if (!e.target.closest('[data-lang]')) return;
    setTimeout(() => {
      if (floatWrap.dataset.key) A.update(floating, { message: say(floatWrap.dataset.key), name: say('meta.name') });
      render();
    }, 50);
  });

  // ---------- Наблюдение за экраном ----------
  // Колбэк MutationObserver срабатывает сразу после перерисовки экрана — аватар возвращается без мигания.
  // Повторная вставка аватара вызывает ещё одно уведомление, но sync() видит, что он на месте, и ничего не делает.
  new MutationObserver(muts => {
    // Свои изменения (реплика, класс состояния) не считаем.
    if (muts.every(m => m.target.closest && m.target.closest('.apprentice'))) return;
    sync();
  }).observe(app, { childList: true, subtree: true });
  sync();
})();

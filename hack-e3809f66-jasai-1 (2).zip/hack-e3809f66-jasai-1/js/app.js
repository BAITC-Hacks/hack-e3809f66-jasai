// TASK FORGE — UI: hash-роутер и экраны. Без фреймворков: открывается как файл.
// Метафора: бизнес куёт задачу (слиток раскаляется с ростом рейтинга), студенты берут контракт.
// Все надписи интерфейса — через tr() из словаря I18N (русский, казахский, английский).
(function () {
  const S = window.Scoring, AI = window.AI, Store = window.Store, FX = window.FX, I18N = window.I18N;
  const tr = I18N.t;
  const app = document.getElementById('app');
  const header = document.getElementById('header');
  const footer = document.getElementById('footer');

  let wiz = null;                       // состояние кузницы (конструктора)
  let sceneScore = null;                // последний показанный рейтинг в сцене — для искр при росте
  const cat = { q: '', industry: '', levels: new Set(), sort: 'rating', view: 'list', hl: null };
  const openScrolls = new Set();        // развёрнутые свитки
  let justStamped = null;               // id контракта, на который только что шлёпнули печать
  let sig = [];                         // штрихи подписи: [[{x,y}...], ...] в координатах 600×200

  // ---------- Утилиты ----------
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const LOCALE = { ru: 'ru-RU', kk: 'kk-KZ', en: 'en-GB' };
  const fmtDate = ts => ts ? new Date(ts).toLocaleString(LOCALE[I18N.getLang()], { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '';
  const st = () => Store.get();
  const isOwner = t => st().role === 'business' && t.company === st().currentCompany;
  const currentTeam = () => Store.team(st().currentTeamId);
  const $ = s => document.querySelector(s);
  const stageName = id => tr('stage.' + id);

  function toast(msg, kind) {
    const el = document.getElementById('toast');
    el.textContent = msg;
    el.className = 'toast show ' + (kind || '');
    clearTimeout(toast.t);
    toast.t = setTimeout(() => { el.className = 'toast'; }, 3600);
  }

  // Медаль-достижение: всплывает с искрами.
  function award(id) {
    const a = Store.unlock(id);
    if (!a) return;
    const box = document.getElementById('medals');
    const m = document.createElement('div');
    m.className = 'medal';
    m.innerHTML = `<span class="medal-icon">${a.icon}</span><div><small>${tr('ach.medal')}</small><b>${esc(tr(`ach.${id}.title`))}</b><span>${esc(tr(`ach.${id}.desc`))}</span></div>`;
    box.appendChild(m);
    setTimeout(() => { FX.burstAt(m.querySelector('.medal-icon'), { count: 18, colors: [FX.COLORS.gold, FX.COLORS.lime, FX.COLORS.white] }); FX.play('spark'); }, 250);
    setTimeout(() => m.classList.add('out'), 4600);
    setTimeout(() => m.remove(), 5200);
  }

  // ---------- Базовые компоненты ----------
  /** Сердце рейтинга: ядро цвета температуры, орбиты вращаются быстрее на высоких уровнях. */
  function heart(score, o) {
    o = o || {};
    const l = S.levelFor(score);
    return `<div class="heart lvl-${l.id} ${o.size || ''}" style="--heat:${S.heatColor(score)};--lc:${l.color}${o.vt ? ';view-transition-name:' + o.vt : ''}">
      <i class="orbit o1"></i><i class="orbit o2"></i><b class="core"><span class="num">${score}</span></b></div>`;
  }
  const badge = score => { const l = S.levelFor(score); return `<span class="badge lvl-${l.id}">${l.label}</span>`; };
  const caption = score => { const l = S.levelFor(score); return `<span class="hand cap lvl-${l.id}">${l.caption}</span>`; };
  const statusDot = s => `<span class="dot st-${s}" title="${tr('dot.' + s)}"></span>`;

  function tempBar(score) {
    // Градиент растянут на всю шкалу: на 50 баллах видна только «оранжевая» половина.
    return `<div class="temp"><div class="temp-track"><div class="temp-fill" style="width:${score}%;background-size:${(10000 / Math.max(score, 1)).toFixed(0)}% 100%"></div>
      ${[40, 70, 90].map(v => `<i style="left:${v}%"></i>`).join('')}</div>
      <div class="temp-legend"><span>${tr('temp.cold')}</span><span class="mono">${Math.round(20 + score * 13)}°</span><span>${tr('temp.blade')}</span></div></div>`;
  }

  function breakdown(sc) {
    return `<h4 class="eyebrow">${tr('bd.title')}</h4>
      <div class="bars">${sc.groups.map(g => `
        <div class="bar ${g.points === g.max ? 'full' : ''}"><div class="bl"><span>${g.label}</span><b class="mono">${g.points}/${g.max}</b></div>
          <div class="track"><div style="width:${g.max ? g.points / g.max * 100 : 0}%"></div></div>
          <small>${g.fields.map(k => `${sc.fields[k].label}: ${sc.fields[k].note.toLowerCase()}`).join(' · ')}</small>
        </div>`).join('')}</div>`;
  }

  function improvements(sc) {
    if (!sc.missing.length) return `<h4 class="eyebrow">${tr('imp.title')}</h4><p class="hand ok">${tr('imp.done')}</p>`;
    return `<h4 class="eyebrow">${tr('imp.title')}</h4>
      <ul class="missing">${sc.missing.map(m => `<li><span class="gain mono">+${m.gain}</span><div><b>${m.label}</b><small>${esc(m.hint)}</small></div></li>`).join('')}</ul>`;
  }

  // ---------- Шапка и подвал ----------
  function renderHeader() {
    const s = st();
    const route = location.hash.split('/')[1] || '';
    const link = (href, key, r) => `<a href="${href}" class="${route === r ? 'active' : ''}">${tr(key)}</a>`;
    const nav = s.role === 'business'
      ? [link('#/forge', 'nav.forge', 'forge'), link('#/business', 'nav.business', 'business'), link('#/catalog', 'nav.catalog', 'catalog'), link('#/teams', 'nav.teams', 'teams'), link('#/ai', 'nav.ai', 'ai')]
      : [link('#/catalog', 'nav.catalog', 'catalog'), link('#/compass', 'nav.compass', 'compass'), link('#/contracts', 'nav.contracts', 'contracts'), link('#/teams', 'nav.teams', 'teams'), link('#/ai', 'nav.ai', 'ai')];
    const who = s.role === 'business'
      ? `<select id="companySel" aria-label="${tr('aria.company')}">${s.companies.map(c => `<option ${c === s.currentCompany ? 'selected' : ''}>${esc(c)}</option>`).join('')}</select>`
      : `<select id="teamSel" aria-label="${tr('aria.team')}">${s.teams.map(t => `<option value="${t.id}" ${t.id === s.currentTeamId ? 'selected' : ''}>${esc(t.name)}</option>`).join('')}</select>`;
    const langs = I18N.LANGS.map(l => `<button class="${l.id === I18N.getLang() ? 'on' : ''}" data-lang="${l.id}" aria-pressed="${l.id === I18N.getLang()}">${l.label}</button>`).join('');
    header.innerHTML = `
      <a class="brand" href="#/"><span>TASK</span><b>FORGE</b></a>
      <nav>${nav.join('')}</nav>
      <div class="role">
        <select id="roleSel" aria-label="${tr('aria.role')}">
          <option value="business" ${s.role === 'business' ? 'selected' : ''}>${tr('role.business')}</option>
          <option value="team" ${s.role === 'team' ? 'selected' : ''}>${tr('role.team')}</option>
        </select>
        ${who}
        <div class="langs" role="group" aria-label="${tr('aria.lang')}">${langs}</div>
        <button class="mute" id="muteBtn" aria-pressed="${!FX.isMuted()}" title="${tr('sound.title')}">${FX.isMuted() ? tr('sound.off') : tr('sound.on')}</button>
      </div>`;
    footer.innerHTML = `<span class="hand">${tr('footer.motto')}</span><span>${tr('footer.name')}</span>`;
  }

  header.addEventListener('change', e => {
    const s = st();
    if (e.target.id === 'roleSel') s.role = e.target.value;
    if (e.target.id === 'companySel') s.currentCompany = e.target.value;
    if (e.target.id === 'teamSel') s.currentTeamId = e.target.value;
    Store.save();
    render();
  });
  header.addEventListener('click', e => {
    if (e.target.id === 'muteBtn') { FX.setMuted(!FX.isMuted()); renderHeader(); }
    const lb = e.target.closest('[data-lang]');
    if (lb && lb.dataset.lang !== I18N.getLang()) {
      I18N.setLang(lb.dataset.lang);
      FX.play('spark');
      FX.transition(render);
    }
  });

  // ---------- Главная (bento) ----------
  function viewHome() {
    const s = st();
    const pub = Store.published();
    const best = pub[0];
    return `
      <section class="hero">
        <p class="eyebrow">${tr('home.eyebrow')}</p>
        <h1>${tr('home.h1')}</h1>
        <p class="lead">${tr('home.lead')}</p>
        <div class="actions">
          <button class="btn primary" data-action="demo">${tr('home.demo')}</button>
          <a class="btn" href="#/forge" data-role="business">${tr('home.forge')}</a>
          <a class="btn ghost" href="#/catalog" data-role="team">${tr('home.take')}</a>
        </div>
      </section>
      <section class="bento">
        <div class="cell big ingot-cell">
          ${ingotSVG()}
          <div class="cell-cap"><span class="hand">${tr('home.ingotHand')}</span><b>${tr('home.ingotTitle')}</b></div>
        </div>
        <div class="cell stat"><b class="mono">${pub.length}</b><span>${tr('home.statTasks', pub.length)}</span></div>
        <div class="cell stat"><b class="mono">${s.proposals.length}</b><span>${tr('home.statContracts', s.proposals.length)}</span></div>
        <div class="cell stat"><b class="mono">${s.teams.length}</b><span>${tr('home.statTeams', s.teams.length)}</span></div>
        ${best ? `<a class="cell best" href="#/task/${best.id}">${heart(best.score)}<div><small class="eyebrow">${tr('home.best')}</small><b>${esc(best.card.title)}</b>${caption(best.score)}</div></a>` : ''}
        <div class="cell steps"><small class="eyebrow">${tr('home.path')}</small><ol>${tr('home.steps').map(x => `<li>${x}</li>`).join('')}</ol></div>
        <div class="cell levels">${S.LEVELS.slice().reverse().map((l, i, arr) => `
          <div class="lv lvl-${l.id}"><b class="mono">${l.min}–${i === arr.length - 1 ? 100 : arr[i + 1].min - 1}</b><span>${l.label}</span><em class="hand">${l.caption}</em></div>`).join('')}</div>
        <div class="cell rule"><span class="hand">${tr('home.ruleHand')}</span><b>${tr('home.ruleTitle')}</b><span>${tr('home.ruleText')}</span></div>
      </section>`;
  }

  // Слиток на наковальне с молотом. Цвет — через CSS-переменные --heat / --rust / --glow у родителя.
  function ingotSVG() {
    return `<svg class="forge-svg" viewBox="0 0 340 230" aria-hidden="true">
      <defs>
        <filter id="blur18"><feGaussianBlur stdDeviation="18"/></filter>
        <linearGradient id="anvilG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2b2d3a"/><stop offset="1" stop-color="#0d0e14"/></linearGradient>
      </defs>
      <ellipse class="glow" cx="160" cy="118" rx="115" ry="38" filter="url(#blur18)"/>
      <path d="M40 150 H285 Q300 150 305 138 L318 138 Q312 162 280 168 L250 170 L262 212 H78 L92 170 L62 168 Q40 165 40 150Z" fill="url(#anvilG)" stroke="#232530"/>
      <g class="ingot">
        <polygon class="ing-side" points="68,148 252,148 236,110 84,110"/>
        <polygon class="ing-top" points="84,110 236,110 222,96 98,96"/>
        <g class="rust"><circle cx="110" cy="130" r="4"/><circle cx="150" cy="138" r="3"/><circle cx="205" cy="126" r="5"/><circle cx="178" cy="120" r="2.5"/><path d="M120 115 l12 14 l-4 10" /></g>
      </g>
      <g class="hammer">
        <rect x="200" y="20" width="118" height="12" rx="5" fill="#4A4D5C"/>
        <rect x="186" y="4" width="34" height="46" rx="6" fill="#8B8FA3" stroke="#D4D7E0" stroke-opacity=".25"/>
      </g>
    </svg>`;
  }

  // ---------- Кузница (конструктор задачи) ----------
  function newWiz() {
    return { taskId: null, step: 1, company: st().currentCompany, industry: SEED.industries[0], draft: '', fields: null,
      questions: [], answers: {}, card: null, confirmedScore: null, dirty: false, loading: false, draftScore: null, lastLog: null };
  }

  function viewForge() {
    if (st().role !== 'business') return `<section class="panel"><h2>${tr('forge.onlyBusinessTitle')}</h2><p>${tr('forge.onlyBusinessText')}</p></section>`;
    if (!wiz || wiz.fromEdit) wiz = newWiz();
    return renderWizard();
  }

  function viewEdit(id) {
    const t = Store.task(id);
    if (!t) return notFound();
    if (!isOwner(t)) return `<section class="panel"><h2>${tr('edit.onlyOwnerTitle')}</h2><p>${esc(tr('edit.onlyOwnerText', t.company))}</p></section>`;
    if (!wiz || wiz.taskId !== id) {
      wiz = { ...newWiz(), taskId: id, fromEdit: true, step: 3, company: t.company, industry: t.industry,
        draft: t.draftText, fields: { ...t.card }, card: { ...t.card }, confirmedScore: t.score };
    }
    return renderWizard();
  }

  // Карточка, которую видит сцена прямо сейчас (на шаге вопросов — с учётом введённых ответов).
  function liveCard() {
    if (!wiz) return AI.emptyCard();
    if (wiz.step === 3 && wiz.card) return wiz.card;
    if (wiz.step === 2 && wiz.fields) {
      const answers = wiz.questions.map((q, i) => ({ field: q.field, answer: wiz.answers[i] || '' }));
      return AI.buildCardLocal({ draft: wiz.draft, fields: wiz.fields, answers }).card;
    }
    return AI.emptyCard();
  }

  function renderWizard() {
    const cur = wiz.step === 3 && wiz.confirmedScore !== null && !wiz.dirty ? 4 : wiz.step;
    let body;
    if (wiz.loading) body = `<section class="panel center anvil-wait"><div class="spinner"></div><p class="hand">${tr('wiz.loading')}</p></section>`;
    else if (wiz.step === 1) body = wizStep1();
    else if (wiz.step === 2) body = wizStep2();
    else body = wizStep3();
    const card = liveCard();
    const sc = S.score(card);
    sceneScore = sc.total;
    return `
      <div class="forge-head">
        <div><p class="eyebrow">${tr('wiz.eyebrow')}</p><h1 class="page-title">${tr(wiz.fromEdit ? 'wiz.titleEdit' : 'wiz.titleNew')}</h1></div>
        ${!wiz.fromEdit && wiz.step > 1 && !wiz.loading ? `<button class="btn ghost small" data-action="restart">${tr('wiz.restart')}</button>` : ''}
      </div>
      <ol class="wsteps">${tr('wiz.steps').map((n, i) => `<li class="${i + 1 < cur ? 'done' : i + 1 === cur ? 'cur' : ''}"><span class="mono">0${i + 1}</span>${n}</li>`).join('')}</ol>
      <div class="forge-grid">
        <div class="forge-main">${body}</div>
        <aside class="scene" id="scene" style="${sceneVars(sc.total)}">
          <div class="stage">${ingotSVG()}</div>
          <div id="scene-dyn">${sceneDyn(card)}</div>
        </aside>
      </div>`;
  }

  function sceneVars(score) {
    return `--heat:${S.heatColor(score)};--rust:${Math.max(0, 1 - score / 35).toFixed(2)};--glow:${(0.15 + score / 110).toFixed(2)};--lc:${S.levelFor(score).color}`;
  }

  function sceneDyn(card) {
    const sc = S.score(card);
    let status = '';
    if (wiz && wiz.step === 3) {
      const conf = wiz.confirmedScore;
      if (conf === null) status = `<p class="note">${tr('scene.preliminary')}</p>`;
      else if (wiz.dirty) { const d = sc.total - conf; status = `<p class="note">${tr('scene.was')} <b class="mono">${conf}</b> → ${tr('scene.willBe')} <b class="mono">${sc.total}</b> <span class="${d >= 0 ? 'up' : 'down'} mono">${d >= 0 ? '+' : ''}${d}</span></p>`; }
      else status = `<p class="note ok">${tr('scene.sealed', conf)}</p>`;
    } else if (wiz && wiz.step === 2) status = `<p class="note">${tr('scene.step2')}</p>`;
    return `
      <div class="scene-head">${heart(sc.total, { size: 'xl' })}<div><p class="eyebrow">${tr('scene.rating')}</p>${badge(sc.total)}<br>${caption(sc.total)}</div></div>
      ${tempBar(sc.total)}
      ${status}
      ${wiz && wiz.step > 1 ? breakdown(sc) + improvements(sc) : `<p class="muted small">${tr('scene.empty')}</p>`}`;
  }

  /** Обновляет сцену без перерисовки формы; при росте рейтинга — искры летят в ядро. */
  function updateScene(fromEl) {
    const scene = $('#scene');
    if (!scene) return;
    const card = liveCard();
    const total = S.score(card).total;
    const prev = sceneScore;
    scene.setAttribute('style', sceneVars(total));
    $('#scene-dyn').innerHTML = sceneDyn(card);
    sceneScore = total;
    const h = scene.querySelector('.heart');
    if (prev !== null && total > prev) {
      h.classList.add('pulse');
      FX.flyTo(fromEl, h, (total - prev) * 1.2);
      FX.play('spark');
      if (S.levelFor(total).id !== S.levelFor(prev).id) {
        setTimeout(() => { FX.burstAt(h, { count: 26, colors: [S.levelFor(total).color, FX.COLORS.white], power: 9 }); FX.play('hammer'); }, 900);
      }
    }
  }

  function strike() {
    const hm = document.querySelector('#scene .hammer');
    if (!hm) return;
    hm.classList.remove('strike'); void hm.getBBox(); hm.classList.add('strike');
    FX.play('hammer');
    setTimeout(() => FX.burstAt(document.querySelector('#scene .ing-top'), { count: 12, power: 6 }), 180);
  }

  function aiBadge() {
    const s = st().settings;
    const log = wiz && wiz.lastLog;
    const p = window.AIProvider.get(s);
    const mode = p.name === 'fallback' ? tr('aib.local') : `${p.label} (${esc(p.model)})`;
    let extra = '';
    if (log && log.fallback) extra = ` · <span class="warn">${esc(tr('aib.rejected', log.errors[0] || ''))}</span>`;
    else if (log && log.grounding.length) extra = ` · <span class="warn">${tr('aib.fixed', log.grounding.length)}</span>`;
    return `<div class="aibadge"><span class="mono">[AI]</span> ${mode}${extra} · <a href="#/ai">${tr('aib.link')}</a></div>`;
  }

  const industryOptions = sel => SEED.industries.map(i => `<option ${i === sel ? 'selected' : ''}>${i}</option>`).join('');

  function wizStep1() {
    return `
      <section class="panel">
        <h2>${tr('s1.title')}</h2>
        <p class="muted">${tr('s1.lead')}</p>
        <div class="row">
          <label>${tr('s1.company')}<input id="w-company" value="${esc(wiz.company)}" maxlength="80"></label>
          <label>${tr('s1.industry')}<select id="w-industry">${industryOptions(wiz.industry)}</select></label>
        </div>
        <label>${tr('s1.draft')}<textarea id="w-draft" rows="5" placeholder="${esc(tr('s1.placeholder'))}">${esc(wiz.draft)}</textarea></label>
        <div class="samples"><span class="muted small">${tr('s1.samples')}</span>
          ${SEED.drafts.map(d => `<button class="chip" data-action="sample" data-id="${d.id}">${esc(d.company)} <span class="mono">${S.score(AI.extractLocal(d.text)).total}°</span></button>`).join('')}
        </div>
        <div class="err" id="w-err"></div>
        <div class="actions"><button class="btn primary" data-action="analyze">${tr('s1.analyze')}</button></div>
        ${aiBadge()}
      </section>`;
  }

  // Вопросы локальной эвристики пересобираются на текущем языке; вопросы модели показываются как есть.
  const PREFIX = { ask: '', refine: 'q.refine', more: 'q.more' };
  const qText = q => (q.kind ? (PREFIX[q.kind] ? tr(PREFIX[q.kind]) : '') + S.byKey[q.field].question : q.question);
  const qHint = q => (q.kind ? S.byKey[q.field].hint : q.hint);

  function wizStep2() {
    const sc = S.score(wiz.fields);
    return `
      <section class="panel">
        <h2>${tr('s2.title')}</h2>
        <p class="muted">${tr('s2.lead')}</p>
        ${wiz.questions.map((q, i) => `
          <div class="qcard ${wiz.answers[i] ? 'hit' : ''}" data-field="${q.field}">
            <div class="qhead"><span class="mono">${tr('s2.hit', i + 1, wiz.questions.length)}</span><span class="tag">${esc(S.byKey[q.field].label)} · ${tr('s2.upTo')} +${S.byKey[q.field].weight - sc.fields[q.field].points}</span></div>
            <label class="q">${esc(qText(q))}<textarea data-q="${i}" rows="2" placeholder="${esc(qHint(q) || '')}">${esc(wiz.answers[i] || '')}</textarea></label>
          </div>`).join('')}
        <div class="actions">
          ${wiz.card ? `<button class="btn ghost" data-action="back3">${tr('s2.backCard')}</button>` : `<button class="btn ghost" data-action="back1">${tr('s2.backDraft')}</button>`}
          <button class="btn primary" data-action="build">${tr('s2.build')}</button>
        </div>
        ${aiBadge()}
      </section>
      <section class="panel extracted-panel">
        <h3>${tr('s2.known')}</h3>
        <ul class="extracted">${S.SCORED.map(f => `<li>${statusDot(S.evaluateField(f.key, wiz.fields[f.key]).status)}<b>${f.label}</b><span>${esc(wiz.fields[f.key]) || `<i class="muted">${tr('s2.none')}</i>`}</span></li>`).join('')}</ul>
      </section>`;
  }

  function wizStep3() {
    const card = wiz.card;
    const sc = S.score(card);
    const canPublish = wiz.confirmedScore !== null && !wiz.dirty;
    const t = wiz.taskId && Store.task(wiz.taskId);
    const published = t && t.status === 'published';
    return `
      <section class="panel">
        <h2>${tr('s3.title')}</h2>
        <p class="muted">${tr('s3.lead')}</p>
        <label class="field"><span>${tr('s1.industry')}</span><select id="w-industry3">${industryOptions(wiz.industry)}</select></label>
        ${S.FIELDS.map(f => {
          const ev = f.weight ? sc.fields[f.key] : null;
          const big = ['context', 'need', 'data', 'expected_result', 'success_criteria'].includes(f.key);
          return `<label class="field">
            <span>${ev ? `<span id="st-${f.key}">${statusDot(ev.status)}</span>` : ''}${f.label}${f.weight ? ` <small class="mono">${f.weight}</small>` : ` <small>${tr('s3.required')}</small>`}</span>
            ${big ? `<textarea data-f="${f.key}" rows="3" placeholder="${esc(f.placeholder)}">${esc(card[f.key])}</textarea>`
                  : `<input data-f="${f.key}" value="${esc(card[f.key])}" placeholder="${esc(f.placeholder)}">`}
          </label>`;
        }).join('')}
        <div class="err" id="w-err"></div>
        <div class="actions">
          ${wiz.fromEdit ? '' : `<button class="btn ghost" data-action="back2">${tr('s3.back')}</button>`}
          <button class="btn ghost" data-action="refine">${tr('s3.refine')}</button>
          <button class="btn primary" data-action="confirm">${tr(published ? 's3.confirmEdit' : 's3.confirm')}</button>
          ${published ? `<a class="btn" href="#/task/${t.id}">${tr('s3.toTask')}</a>` : `<button class="btn hot" data-action="publish" ${canPublish ? '' : `disabled title="${tr('s3.publishHint')}"`}>${tr('s3.publish')}</button>`}
        </div>
        ${aiBadge()}
      </section>`;
  }

  // ---------- Действия кузницы ----------
  async function runAI(kind, input) {
    wiz.loading = true; render();
    const { result, log } = await AI.run(kind, { ...input, lang: I18N.getLang() }, st().settings, entry => Store.logAI(entry));
    wiz.loading = false;
    wiz.lastLog = log;
    return result;
  }

  async function doAnalyze() {
    wiz.company = $('#w-company').value.trim();
    wiz.industry = $('#w-industry').value;
    wiz.draft = $('#w-draft').value.trim();
    const errs = [];
    if (wiz.company.length < 2) errs.push(tr('err.company'));
    if (wiz.draft.length < 20) errs.push(tr('err.draftShort'));
    if (wiz.draft.length > 5000) errs.push(tr('err.draftLong'));
    if (errs.length) { $('#w-err').innerHTML = errs.join('<br>'); return; }
    strike();
    const res = await runAI('analyze', { draft: wiz.draft, industry: wiz.industry });
    wiz.fields = res.fields;
    wiz.questions = res.questions;
    wiz.answers = {};
    wiz.draftScore = S.score(res.fields).total;
    wiz.step = 2;
    render();
    award('first-strike');
  }

  async function doBuild() {
    const answers = wiz.questions.map((q, i) => ({ field: q.field, question: q.question, answer: (wiz.answers[i] || '').trim() }));
    const res = await runAI('buildCard', { draft: wiz.draft, fields: wiz.fields, answers });
    wiz.card = res.card;
    wiz.dirty = wiz.confirmedScore !== null;
    wiz.step = 3;
    render();
    strike();
  }

  async function doRefine() {
    const res = await runAI('analyze', { draft: wiz.draft, known: wiz.card, industry: wiz.industry });
    wiz.fields = { ...wiz.card };        // текущий текст карточки не перезаписывается
    wiz.questions = res.questions;
    wiz.answers = {};
    wiz.step = 2;
    render();
  }

  function doConfirm() {
    const c = wiz.card;
    const errs = [];
    if (!c.title || c.title.trim().length < 5) errs.push(tr('err.title'));
    if (c.title && c.title.length > 120) errs.push(tr('err.titleLong'));
    if (!S.SCORED.some(f => (c[f.key] || '').trim())) errs.push(tr('err.empty'));
    if (errs.length) { $('#w-err').innerHTML = errs.join('<br>'); return; }
    const card = Object.fromEntries(Object.entries(c).map(([k, v]) => [k, String(v || '').trim()]));
    const before = wiz.confirmedScore;
    const t = Store.confirmCard({ taskId: wiz.taskId, company: wiz.company, industry: wiz.industry, draftText: wiz.draft, draftScore: wiz.draftScore, card });
    if (!st().companies.includes(wiz.company)) Store.addCompany(wiz.company);
    st().currentCompany = t.company; Store.save();
    wiz.taskId = t.id; wiz.confirmedScore = t.score; wiz.dirty = false; wiz.card = card;
    const pos = t.status === 'published' ? tr('toast.pos', Store.catalogPosition(t.id)) : '';
    toast(before === null ? tr('toast.sealed', t.score) : tr('toast.reforged', before, t.score) + pos, 'ok');
    render();
    strike();
    if (t.score >= 90) award('detail-master');
  }

  async function doPublish() {
    const id = wiz.taskId;
    await FX.ritual($('#scene .stage'));
    const t = Store.publish(id);
    wiz = null;
    cat.hl = t.id;
    toast(tr('toast.published', Store.catalogPosition(t.id), Store.published().length), 'ok');
    location.hash = '#/catalog';
    if (t.score >= 70) setTimeout(() => award('perfect-alloy'), 400);
  }

  // ---------- Каталог: List + Hunt Map ----------
  function viewCatalog() {
    const s = st();
    const all = Store.published();
    const recs = s.role === 'team' ? AI.recommend(currentTeam(), all).slice(0, 3) : [];
    return `
      <div class="forge-head">
        <div><p class="eyebrow">${tr('cat.eyebrow', all.length)}</p><h1 class="page-title">${tr('cat.title')}</h1></div>
        <div class="seg">
          <button class="${cat.view === 'list' ? 'on' : ''}" data-action="view" data-id="list">${tr('cat.list')}</button>
          <button class="${cat.view === 'map' ? 'on' : ''}" data-action="view" data-id="map">${tr('cat.map')}</button>
        </div>
      </div>
      ${recs.length ? `<a class="panel recs-strip" href="#/compass"><span class="hand">${esc(tr('cat.compassStrip', currentTeam().name))}</span> ${recs.map(r => `<b>${esc(r.task.card.title)}</b>`).join(' · ')} →</a>` : ''}
      <section class="panel filters">
        <input id="f-q" placeholder="${tr('cat.search')}" value="${esc(cat.q)}">
        <select id="f-sort" aria-label="${tr('cat.sort')}">
          <option value="rating" ${cat.sort === 'rating' ? 'selected' : ''}>${tr('cat.sortRating')}</option>
          <option value="date" ${cat.sort === 'date' ? 'selected' : ''}>${tr('cat.sortDate')}</option>
          <option value="title" ${cat.sort === 'title' ? 'selected' : ''}>${tr('cat.sortTitle')}</option>
        </select>
        <div class="chips"><span class="muted small">${tr('cat.industry')}</span>
          <button class="chip ${!cat.industry ? 'on' : ''}" data-action="ind" data-id="">${tr('cat.all')}</button>
          ${SEED.industries.map(i => `<button class="chip ${cat.industry === i ? 'on' : ''}" data-action="ind" data-id="${i}">${i}</button>`).join('')}
        </div>
        <div class="chips"><span class="muted small">${tr('cat.level')}</span>
          ${S.LEVELS.map(l => `<button class="chip lvlchip lvl-${l.id} ${cat.levels.has(l.id) ? 'on' : ''}" data-action="lvl" data-id="${l.id}">${l.label}</button>`).join('')}
        </div>
      </section>
      <div id="catalog-body">${catalogBody()}</div>`;
  }

  function filtered() {
    const all = Store.published();
    const q = cat.q.toLowerCase();
    let list = all.filter(t =>
      (!cat.industry || t.industry === cat.industry) &&
      (!cat.levels.size || cat.levels.has(S.levelFor(t.score).id)) &&
      (!q || (t.company + ' ' + Object.values(t.card).join(' ')).toLowerCase().includes(q)));
    if (cat.sort === 'date') list = list.slice().sort((a, b) => (b.publishedAt || 0) - (a.publishedAt || 0));
    if (cat.sort === 'title') list = list.slice().sort((a, b) => a.card.title.localeCompare(b.card.title, LOCALE[I18N.getLang()]));
    return { all, list };
  }

  function catalogBody() {
    const { all, list } = filtered();
    if (!list.length) return `<section class="panel"><p class="hand">${tr('cat.empty')}</p></section>`;
    if (cat.view === 'map') return huntMap(list);
    return `<div class="tiles">${list.map(t => tile(t, all.indexOf(t) + 1)).join('')}</div>`;
  }

  function tile(t, pos) {
    const l = S.levelFor(t.score);
    const n = Store.proposalsFor(t.id).length;
    return `<a class="tile lvl-${l.id} ${cat.hl === t.id ? 'landed' : ''}" href="#/task/${t.id}" data-tid="${t.id}" style="--lc:${l.color};--heat:${S.heatColor(t.score)}">
      <div class="tilehead"><span class="pos mono">#${pos}</span>${heart(t.score, { vt: 'h-' + t.id })}</div>
      <h3 style="view-transition-name:t-${t.id}">${esc(t.card.title)}</h3>
      <div class="muted small">${esc(t.company)} · ${esc(t.industry)}</div>
      <p>${esc((t.card.need || t.card.context || '').slice(0, 130))}</p>
      <div class="tilefoot">${badge(t.score)}${Store.inWork(t.id) ? `<span class="badge work">${tr('tile.inWork')}</span>` : ''}<span class="muted small">${tr('tile.contracts', n)}</span></div>
      ${caption(t.score)}
    </a>`;
  }

  // Hunt Map: X — сложность (эвристика по ключевым словам), Y — готовность (рейтинг).
  function huntMap(list) {
    return `<section class="panel map-wrap">
      <div class="huntmap"><div class="plot">
        ${['priority', 'ready', 'working', 'draft'].map(z => `<div class="zone z-${z}"><span>${tr('map.zone.' + z)}</span></div>`).join('')}
        ${list.map(t => {
          const l = S.levelFor(t.score), cx = S.complexity(t.card);
          const size = 12 + Math.min(4, Store.proposalsFor(t.id).length) * 4;
          return `<a class="star lvl-${l.id}" href="#/task/${t.id}" style="left:${(cx - 0.5) * 10}%;bottom:${t.score}%;--lc:${l.color};--s:${size}px">
            <i></i><span class="star-tip"><b>${esc(t.card.title)}</b><small class="mono">${tr('map.tip', t.score, cx)}</small></span></a>`;
        }).join('')}
      </div></div>
      <div class="axis-x"><span>${tr('map.simpler')}</span><span class="mono">${tr('map.axis')}</span><span>${tr('map.harder')}</span></div>
      <p class="muted small">${tr('map.note')}</p>
    </section>`;
  }

  // ---------- Страница задачи ----------
  function viewTask(id) {
    const t = Store.task(id);
    if (!t) return notFound();
    const s = st();
    const sc = S.score(t.card);
    const owner = isOwner(t);
    if (t.status !== 'published' && !owner) return notFound();
    const l = S.levelFor(t.score);

    const fieldsHtml = S.SCORED.map(f => `<div class="cf">${statusDot(sc.fields[f.key].status)}<b>${f.label}</b><p>${esc(t.card[f.key]) || `<i class="muted">${tr('task.notSpecified')}</i>`}</p></div>`).join('');
    const history = `<div class="history">${t.history.map((h, i) => `${i ? '<span class="arrow">→</span>' : ''}<span class="hchip lvl-${S.levelFor(h.score).id} mono" title="${esc(tr('hist.' + h.note))} · ${fmtDate(h.at)}">${h.score}</span>`).join('')}</div>`;

    let bottom;
    if (owner) bottom = scrollsForBusiness(t);
    else if (s.role === 'team') bottom = contractForm(t);
    else bottom = `<section class="panel"><h2>${tr('task.scrolls')}</h2><p class="muted">${tr('task.scrollsViewer', Store.proposalsFor(t.id).length)}</p></section>`;

    return `
      <div class="task-top" style="--lc:${l.color}">
        <div>
          <div class="muted small crumbs"><a href="#/catalog">${tr('task.back')}</a> · ${esc(t.company)} · ${esc(t.industry)}</div>
          <h1 class="page-title" style="view-transition-name:t-${t.id}">${esc(t.card.title)}</h1>
          <div class="tilefoot">${badge(t.score)}${Store.inWork(t.id) ? `<span class="badge work">${tr('tile.inWork')}</span>` : ''}
            ${t.status === 'published' ? `<span class="muted">${tr('task.pos', Store.catalogPosition(t.id), Store.published().length)}</span>` : `<span class="badge">${tr('task.unpublished')}</span>`}</div>
          ${caption(t.score)}
        </div>
        ${heart(t.score, { size: 'xl', vt: 'h-' + t.id })}
      </div>
      <div class="split">
        <section class="panel">${fieldsHtml}</section>
        <aside class="panel side">
          <h4 class="eyebrow">${tr('task.history')}</h4>${history}
          ${tempBar(t.score)}
          ${owner ? `<div class="actions"><a class="btn primary" href="#/edit/${t.id}">${tr('task.reforge')}</a>${t.status !== 'published' ? `<button class="btn hot" data-action="publish-task" data-id="${t.id}">${tr('task.publish')}</button>` : ''}</div>` : ''}
          ${breakdown(sc)}
          ${improvements(sc)}
        </aside>
      </div>
      ${bottom}`;
  }

  // Форма-контракт команды с подписью на canvas.
  function contractForm(t) {
    const team = currentTeam();
    const mine = Store.proposalsFor(t.id).filter(p => p.teamId === team.id);
    const draft = S.levelFor(t.score).id === 'draft';
    return `
      <section class="panel contract" id="contract-form">
        <div class="contract-head"><div><p class="eyebrow">${tr('cf.eyebrow')}</p><h2>${tr('cf.title')}</h2></div><span class="hand">${tr('cf.hand')}</span></div>
        ${draft ? `<p class="note">${tr('cf.cold')}</p>` : ''}
        ${mine.length ? `<p>${tr('cf.mine')} ${mine.map(p => `<span class="badge ps-${p.status}">${tr('status.' + p.status)}</span>`).join(' ')} · <a href="#/contracts">${tr('cf.all')}</a></p>` : ''}
        <div class="row">
          <label>${tr('cf.team')}<select id="cf-team">${st().teams.map(x => `<option value="${x.id}" ${x.id === team.id ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>
          <label>${tr('cf.weeks')}<input id="cf-weeks" type="number" min="1" max="52" placeholder="6"></label>
          <label>${tr('cf.link')}<input id="cf-link" placeholder="https://..."></label>
        </div>
        <label>${tr('cf.idea')} <small class="muted">${tr('cf.min50')}</small><textarea id="cf-idea" rows="3"></textarea></label>
        <label>${tr('cf.plan')} <small class="muted">${tr('cf.min50')}</small><textarea id="cf-plan" rows="3"></textarea></label>
        <div class="sigbox"><span>${tr('cf.sig')} <small class="muted">${tr('cf.sigHint')}</small></span>
          <canvas id="sig" width="600" height="200"></canvas>
          <button class="btn ghost small" data-action="sig-clear">${tr('cf.clear')}</button>
        </div>
        <div class="err" id="cf-err"></div>
        <div class="actions"><button class="btn hot" data-action="propose" data-id="${t.id}">${tr('cf.submit')}</button></div>
        <p class="muted small">${tr('cf.note')}</p>
      </section>`;
  }

  function sigPath(strokes) {
    return strokes.filter(s => s.length > 1).map(s => 'M' + s.map(p => `${(p.x / 2).toFixed(1)} ${(p.y / 2).toFixed(1)}`).join(' L')).join(' ');
  }
  const sigSVG = s => s && s.d ? `<svg class="sig-svg" viewBox="0 0 ${s.w} ${s.h}"><path d="${esc(s.d)}"/></svg>` : '';

  function initSignature() {
    const c = $('#sig');
    if (!c) return;
    sig = [];
    const g = c.getContext('2d');
    g.lineWidth = 4; g.lineCap = 'round'; g.lineJoin = 'round'; g.strokeStyle = '#C8FF3D';
    g.shadowColor = '#C8FF3D'; g.shadowBlur = 8;
    let drawing = false;
    const pt = e => { const r = c.getBoundingClientRect(); return { x: (e.clientX - r.left) * c.width / r.width, y: (e.clientY - r.top) * c.height / r.height }; };
    c.addEventListener('pointerdown', e => { drawing = true; c.setPointerCapture(e.pointerId); const p = pt(e); sig.push([p]); g.beginPath(); g.moveTo(p.x, p.y); });
    c.addEventListener('pointermove', e => { if (!drawing) return; const p = pt(e); sig[sig.length - 1].push(p); g.lineTo(p.x, p.y); g.stroke(); });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => c.addEventListener(ev, () => { drawing = false; }));
  }

  /** Для демо: рисует росчерк программно. */
  function drawDemoSignature() {
    const c = $('#sig');
    if (!c) return;
    const g = c.getContext('2d');
    sig = [[]];
    g.beginPath();
    for (let i = 0; i <= 60; i++) {
      const t = i / 60, x = 40 + t * 500, y = 110 + Math.sin(t * 9) * 45 + Math.cos(t * 23) * 12;
      sig[0].push({ x, y });
      if (i === 0) g.moveTo(x, y); else g.lineTo(x, y);
    }
    g.stroke();
  }

  async function doPropose(taskId) {
    const v = id => $(id).value.trim();
    const p = { taskId, teamId: v('#cf-team'), idea: v('#cf-idea'), plan: v('#cf-plan'), weeks: parseInt(v('#cf-weeks'), 10), link: v('#cf-link') };
    const errs = [];
    if (p.idea.length < 50) errs.push(tr('err.idea', p.idea.length));
    if (p.plan.length < 50) errs.push(tr('err.plan', p.plan.length));
    if (!(p.weeks >= 1 && p.weeks <= 52)) errs.push(tr('err.weeks'));
    if (p.link && !/^https?:\/\/\S+\.\S+/.test(p.link)) errs.push(tr('err.link'));
    const d = sigPath(sig);
    if (!d) errs.push(tr('err.sig'));
    if (errs.length) { $('#cf-err').innerHTML = errs.join('<br>'); return; }
    p.signature = { d, w: 300, h: 100 };
    const form = $('#contract-form');
    FX.play('paper');
    form.classList.add('roll');
    await new Promise(r => setTimeout(r, FX.reduced ? 50 : 1000));
    Store.addProposal(p);
    st().currentTeamId = p.teamId; Store.save();
    toast(tr('toast.sent'), 'ok');
    render();
    award('first-contract');
  }

  // Свитки-контракты для владельца задачи: разворачиваются, принимают печать.
  function scrollsForBusiness(t) {
    const list = Store.proposalsFor(t.id);
    return `
      <section class="panel scrolls-panel">
        <div class="contract-head"><div><p class="eyebrow">${tr('sc.eyebrow')}</p><h2>${tr('sc.title', list.length)}</h2></div>
          <span class="hand">${tr('sc.hand')}</span></div>
        ${list.length ? list.map(p => scroll(p, true)).join('') : `<p class="hand">${tr('sc.empty')}</p>`}
      </section>`;
  }

  function scroll(p, manage) {
    const team = Store.team(p.teamId);
    const open = openScrolls.has(p.id) || !manage;
    const done = p.stages.map(s => s.id);
    const left = SEED.stages.filter(s => !done.includes(s.id));
    const stamp = p.status === 'pending' ? '' : `<div class="stamp ${p.status} ${justStamped === p.id ? 'slam' : ''}">${tr('stamp.' + p.status)}</div>`;
    const task = Store.task(p.taskId);
    return `<article class="scroll ps-${p.status} ${open ? 'open' : ''}" data-sid="${p.id}">
      <div class="rod"></div>
      <button class="scroll-head" ${manage ? `data-action="unroll" data-id="${p.id}"` : 'tabindex="-1"'}>
        <b>${esc(team.name)}</b>
        ${manage ? '' : `<span>${esc(task.card.title)}</span>`}
        <span class="mono">${tr('scroll.weeks', p.weeks)}</span>
        <span class="badge ps-${p.status}">${tr('status.' + p.status)}</span>
        ${manage ? `<span class="muted small toggle-label">${tr(open ? 'scroll.collapse' : 'scroll.expand')}</span>` : ''}
      </button>
      <div class="scroll-body"><div class="scroll-inner">
        <p class="muted small">${tr('scroll.skills')}: ${esc([...team.skills, ...team.tech].join(', '))} · ${fmtDate(p.createdAt)}</p>
        <p><b>${tr('scroll.idea')}</b> ${esc(p.idea)}</p>
        <p><b>${tr('scroll.plan')}</b> ${esc(p.plan)}</p>
        ${p.link ? `<p><b>${tr('scroll.proto')}</b> <a href="${esc(p.link)}" target="_blank" rel="noopener">${esc(p.link)}</a></p>` : ''}
        <div class="sig-line"><span class="muted small">${tr('scroll.sig')}</span>${sigSVG(p.signature)}</div>
        ${manage ? `<div class="actions">
          ${p.status !== 'accepted' ? `<button class="btn hot" data-action="p-accept" data-id="${p.id}">${tr('scroll.accept')}</button>` : ''}
          ${p.status !== 'rejected' ? `<button class="btn danger" data-action="p-reject" data-id="${p.id}">${tr('scroll.reject')}</button>` : ''}
          ${p.status !== 'pending' ? `<button class="btn ghost" data-action="p-reset" data-id="${p.id}">${tr('scroll.unseal')}</button>` : ''}
        </div>` : ''}
        ${p.status === 'accepted' ? `<div class="stages"><b>${tr('scroll.stages')}</b>
          ${p.stages.map(s => `<span class="badge ps-accepted">${esc(stageName(s.id))} +${s.points}</span>`).join(' ') || `<span class="muted">${tr('scroll.noStages')}</span>`}
          ${manage && left.length ? `<select id="stage-${p.id}">${left.map(s => `<option value="${s.id}">${esc(stageName(s.id))} (+${s.points})</option>`).join('')}</select>
            <button class="btn ghost small" data-action="p-stage" data-id="${p.id}">${tr('scroll.confirmStage')}</button>` : ''}
        </div>` : ''}
      </div></div>
      <div class="rod"></div>
      ${stamp}
    </article>`;
  }

  function decide(id, status) {
    Store.setProposalStatus(id, status);
    openScrolls.add(id);
    justStamped = id;
    render();
    justStamped = null;
    const el = document.querySelector(`[data-sid="${id}"] .stamp`);
    setTimeout(() => {
      FX.play('stamp');
      FX.burstAt(el, { count: status === 'accepted' ? 22 : 10, colors: status === 'accepted' ? [FX.COLORS.lime, FX.COLORS.gold, FX.COLORS.white] : [FX.COLORS.rust, FX.COLORS.ember] });
    }, FX.reduced ? 0 : 260);
    if (status === 'accepted') { toast(tr('toast.accepted'), 'ok'); setTimeout(() => award('generous-master'), 700); }
    else toast(tr('toast.rejected'));
  }

  // ---------- Бизнес: мои сплавы ----------
  function viewBusiness() {
    const s = st();
    if (s.role !== 'business') return notFound();
    const tasks = s.tasks.filter(t => t.company === s.currentCompany).sort((a, b) => b.score - a.score);
    return `
      <div class="forge-head"><div><p class="eyebrow">${esc(s.currentCompany)}</p><h1 class="page-title">${tr('biz.title')}</h1></div>
        <a class="btn primary" href="#/forge">${tr('biz.new')}</a></div>
      ${tasks.length ? `<div class="tiles">${tasks.map(t => {
        const ps = Store.proposalsFor(t.id), fresh = ps.filter(p => p.status === 'pending').length;
        const l = S.levelFor(t.score);
        return `<a class="tile lvl-${l.id}" href="#/task/${t.id}" style="--lc:${l.color};--heat:${S.heatColor(t.score)}">
          <div class="tilehead"><span class="pos mono">${t.status === 'published' ? '#' + Store.catalogPosition(t.id) : '—'}</span>${heart(t.score, { vt: 'h-' + t.id })}</div>
          <h3 style="view-transition-name:t-${t.id}">${esc(t.card.title)}</h3>
          <div class="tilefoot">${badge(t.score)}${t.status !== 'published' ? `<span class="badge">${tr('biz.unpublished')}</span>` : ''}${Store.inWork(t.id) ? `<span class="badge work">${tr('tile.inWork')}</span>` : ''}</div>
          <p class="small">${tr('biz.scrolls', ps.length)}${fresh ? ` · <b class="warn">${tr('biz.waiting', fresh)}</b>` : ''}</p>
          ${caption(t.score)}
        </a>`;
      }).join('')}</div>` : `<section class="panel"><p class="hand">${tr('biz.empty')}</p></section>`}
      ${achievementsShelf()}`;
  }

  function achievementsShelf() {
    const got = st().achievements;
    return `<section class="panel"><p class="eyebrow">${tr('ach.eyebrow')}</p><h2>${tr('ach.title')}</h2>
      <div class="shelf">${SEED.achievements.map(a => `<div class="ach ${got[a.id] ? 'got' : ''}"><span class="medal-icon">${a.icon}</span><b>${esc(tr(`ach.${a.id}.title`))}</b><small>${esc(tr(`ach.${a.id}.desc`))}</small></div>`).join('')}</div></section>`;
  }

  // ---------- Студент: компас и контракты ----------
  function viewCompass() {
    const s = st();
    if (s.role !== 'team') return notFound();
    const team = currentTeam();
    const recs = AI.recommend(team, Store.published()).slice(0, 5);
    const [n, e, so, w] = tr('compass.dial');
    return `
      <div class="forge-head"><div><p class="eyebrow">${esc(team.name)}</p><h1 class="page-title">${tr('compass.title')}</h1></div>
        <a class="btn ghost" href="#/catalog">${tr('compass.all')}</a></div>
      <div class="compass-grid">
        <div class="compass" id="compass"><div class="dial">${Array.from({ length: 24 }, (_, i) => `<i style="transform:rotate(${i * 15}deg)"></i>`).join('')}
          <span class="n">${n}</span><span class="e">${e}</span><span class="s">${so}</span><span class="w">${w}</span></div>
          <div class="needle" id="needle"></div><b class="hub"></b></div>
        <div>
          <p class="muted">${tr('compass.note')}</p>
          ${recs.length ? recs.map((r, i) => `<a class="rec ${i === 0 ? 'best' : ''}" href="#/task/${r.task.id}" ${i === 0 ? 'id="best-rec"' : ''}>
            ${heart(r.task.score)}
            <div>${i === 0 ? `<span class="hand">${tr('compass.best')}</span>` : ''}<b>${esc(r.task.card.title)}</b>
              <small>${esc(tr('compass.why', r.hits.map(h => `«${h}»`).join(', ')))}</small></div></a>`).join('')
            : `<p class="hand">${tr('compass.empty')}</p>`}
        </div>
      </div>`;
  }

  // Стрелка компаса раскручивается и замирает, указывая на лучшую задачу.
  // Угол считается после загрузки шрифтов, когда раскладка карточек уже окончательная.
  function aimCompass() {
    const aim = () => {
      const needle = $('#needle'), best = $('#best-rec'), c = $('#compass');
      if (!needle) return;
      let angle = 0;
      if (best) {
        const a = c.getBoundingClientRect(), b = best.getBoundingClientRect();
        angle = Math.atan2((b.top + b.height / 2) - (a.top + a.height / 2), (b.left + 20) - (a.left + a.width / 2)) * 180 / Math.PI + 90;
      }
      needle.style.transform = `rotate(${angle + 720}deg)`;
    };
    (document.fonts ? document.fonts.ready : Promise.resolve()).then(() => requestAnimationFrame(aim));
  }

  function viewContracts() {
    const s = st();
    if (s.role !== 'team') return notFound();
    const team = currentTeam();
    const list = s.proposals.filter(p => p.teamId === team.id).sort((a, b) => b.createdAt - a.createdAt);
    return `
      <div class="forge-head"><div><p class="eyebrow">${esc(tr('contracts.eyebrow', team.name, Store.teamPoints(team.id)))}</p><h1 class="page-title">${tr('contracts.title')}</h1></div></div>
      ${list.length ? list.map(p => scroll(p, false)).join('') : `<section class="panel"><p class="hand">${tr('contracts.empty')}</p><a class="btn" href="#/compass">${tr('contracts.open')}</a></section>`}`;
  }

  // ---------- Гильдии ----------
  function viewTeams() {
    const s = st();
    const teams = s.teams.map(t => ({ ...t, points: Store.teamPoints(t.id), acc: s.proposals.filter(p => p.teamId === t.id && p.status === 'accepted').length }))
      .sort((a, b) => b.points - a.points);
    return `
      <div class="forge-head"><div><p class="eyebrow">${tr('teams.eyebrow')}</p><h1 class="page-title">${tr('teams.title')}</h1></div></div>
      <p class="muted">${tr('teams.note')}</p>
      <div class="guilds">${teams.map((t, i) => `
        <div class="guild ${i === 0 && t.points ? 'lead' : ''}">
          <span class="mono rank">${String(i + 1).padStart(2, '0')}</span>
          <div><b>${esc(t.name)}</b><small>${esc(t.interests.join(' · '))}</small>
            <div class="chips">${[...t.skills, ...t.tech].map(x => `<span class="chip static">${esc(x)}</span>`).join('')}</div></div>
          <div class="pts"><b class="mono">${t.points}</b><small>${tr('teams.pts', t.points, t.acc)}</small></div>
        </div>`).join('')}</div>`;
  }

  // ---------- ИИ: настройки, промпты, журнал ----------
  const BAD_SAMPLES = [
    'Конечно! Вот карточка задачи: {title: "Бот для кофейни", ...}',
    JSON.stringify({ fields: { title: 'Бот для кофейни', context: 42 }, questions: [{ field: 'budget', question: 'Какой бюджет?' }] }),
    JSON.stringify({ fields: { ...AI.emptyCard(), title: 'Чат-бот для кофейни', need: 'Принимать заказы через чат-бота.', success_criteria: 'Конверсия в заказ не ниже 35%, 500 заказов в месяц.', constraints: 'Бюджет 2 млн тенге, срок 3 месяца, стек Django и PostgreSQL.' }, questions: [{ field: 'data', question: 'Какие данные о заказах у вас есть?', hint: 'Например: выгрузка из кассы' }] }),
  ];

  function viewAI() {
    const s = st().settings;
    const log = st().aiLog;
    return `
      <div class="forge-head"><div><p class="eyebrow">${tr('ai.eyebrow')}</p><h1 class="page-title">${tr('ai.title')}</h1></div></div>
      <section class="panel">
        <h2>${tr('ai.mode')}</h2>
        <p class="muted">${tr('ai.modeText')}</p>
        <div class="row">
          <label>${tr('ai.mode')}<select id="ai-mode"><option value="auto" ${s.mode !== 'local' ? 'selected' : ''}>${tr('ai.auto')}</option><option value="local" ${s.mode === 'local' ? 'selected' : ''}>${tr('ai.local')}</option></select></label>
        </div>
        <div class="row">
          <label><span class="mono">1 · Grok (xAI)</span> XAI_API_KEY<input id="ai-xkey" type="password" value="${esc(s.xaiKey || '')}" placeholder="xai-..."></label>
          <label>${tr('ai.model')} Grok<input id="ai-xmodel" value="${esc(s.xaiModel || 'grok-3-mini')}"></label>
        </div>
        <div class="row">
          <label><span class="mono">2 · OpenAI</span> OPENAI_API_KEY<input id="ai-key" type="password" value="${esc(s.apiKey)}" placeholder="sk-..."></label>
          <label>${tr('ai.model')} OpenAI<input id="ai-model" value="${esc(s.model)}"></label>
        </div>
        <p class="note">${tr('ai.active')}: <b>${esc(window.AIProvider.get(s).name === 'fallback' ? tr('ai.local') : window.AIProvider.get(s).label + ' · ' + window.AIProvider.get(s).model)}</b></p>
        <p class="muted small">${tr('ai.keyNote')}</p>
        <div class="actions"><button class="btn primary" data-action="ai-save">${tr('ai.save')}</button><button class="btn danger" data-action="reset-data">${tr('ai.reset')}</button></div>
      </section>
      <section class="panel">
        <h2>${tr('ai.prompts')}</h2>
        <p class="muted small">${tr('ai.promptsDoc')}</p>
        ${['analyze', 'buildCard'].map(k => `
          <details><summary><b>${tr(k === 'analyze' ? 'ai.analyze' : 'ai.build')}</b></summary>
            <h4>${tr('ai.system')}</h4><pre>${esc(AI.PROMPTS[k].system)}</pre>
            <h4>${tr('ai.input')}</h4><pre>${esc(k === 'analyze'
              ? JSON.stringify({ draft: '…', industry: 'Retail', lang: 'ru | kk | en', known: '(optional) current card fields' }, null, 2)
              : JSON.stringify({ draft: '…', lang: 'ru | kk | en', fields: { context: '…', '…': '…' }, answers: [{ field: 'data', question: '…', answer: '…' }] }, null, 2))}</pre>
            <h4>${tr('ai.output')}</h4><pre>${esc(JSON.stringify(AI.SCHEMAS[k], null, 2))}</pre>
          </details>`).join('')}
      </section>
      <section class="panel">
        <h2>${tr('ai.bad')}</h2>
        <p class="muted">${tr('ai.badText')}</p>
        <div class="actions">${tr('ai.badLabels').map((b, i) => `<button class="btn ghost" data-action="bad" data-id="${i}">${b}</button>`).join('')}</div>
        <div id="bad-out"></div>
      </section>
      <section class="panel">
        <h2>${tr('ai.log', log.length)}</h2>
        ${log.length ? log.map(logEntry).join('') : `<p class="muted">${tr('ai.logEmpty')}</p>`}
      </section>`;
  }

  function logEntry(l) {
    const flag = l.fallback ? '<span class="badge danger">fallback</span>' : l.grounding.length ? `<span class="badge warnb">${tr('ai.fixed')}</span>` : '<span class="badge ps-accepted">ok</span>';
    return `<details class="log"><summary>${fmtDate(l.at)} · <b>${l.op}</b> · <span class="mono">${esc(l.model)}</span> ${flag}</summary>
      ${l.errors.length ? `<h4>${tr('ai.errors')}</h4><ul>${l.errors.map(e => `<li>${esc(e)}</li>`).join('')}</ul>` : ''}
      ${l.grounding.length ? `<h4>${tr('ai.factcheck')}</h4><ul>${l.grounding.map(e => `<li>${esc(e)}</li>`).join('')}</ul>` : ''}
      <h4>${tr('ai.inputH')}</h4><pre>${esc(JSON.stringify(l.input, null, 2))}</pre>
      ${l.raw ? `<h4>${tr('ai.raw')}</h4><pre>${esc(l.raw)}</pre>` : ''}
      <h4>${tr('ai.result')}</h4><pre>${esc(JSON.stringify(l.output, null, 2))}</pre>
    </details>`;
  }

  function runBadSample(i) {
    const input = { draft: 'Хотим чат-бота для кофейни, чтобы принимать заказы.', industry: 'HoReCa' };
    const log = { errors: [], grounding: [], fallback: false };
    const out = AI.processRaw('analyze', input, BAD_SAMPLES[i], log);
    console.log('[AI] invalid response check', tr('ai.badLabels')[i], log);
    $('#bad-out').innerHTML = `
      <h4>${tr('ai.modelAnswer')}</h4><pre>${esc(BAD_SAMPLES[i])}</pre>
      <h4>${tr('ai.validator')}</h4>
      <ul>${[...log.errors.map(e => tr('ai.error') + ': ' + e), ...log.grounding.map(g => tr('ai.factcheck') + ': ' + g)].map(x => `<li>${esc(x)}</li>`).join('') || `<li>${tr('ai.noErrors')}</li>`}</ul>
      <p>${tr(log.fallback ? 'ai.rejectedMsg' : 'ai.acceptedMsg')}</p>
      <h4>${tr('ai.final')}</h4><pre>${esc(JSON.stringify(out, null, 2))}</pre>`;
  }

  function notFound() {
    return `<section class="panel"><h2>${tr('nf.title')}</h2><p><a href="#/catalog">${tr('nf.back')}</a></p></section>`;
  }

  // ---------- Роутер ----------
  function render() {
    document.title = tr('meta.title');
    renderHeader();
    const [, route, id] = location.hash.split('/');
    let html;
    switch (route || '') {
      case '': html = viewHome(); break;
      case 'forge': html = viewForge(); break;
      case 'edit': html = viewEdit(id); break;
      case 'catalog': html = viewCatalog(); break;
      case 'task': html = viewTask(id); break;
      case 'business': html = viewBusiness(); break;
      case 'compass': html = viewCompass(); break;
      case 'contracts': html = viewContracts(); break;
      case 'teams': html = viewTeams(); break;
      case 'ai': html = viewAI(); break;
      default: html = notFound();
    }
    app.innerHTML = html;
    afterRender(route || '');
  }

  function afterRender(route) {
    initSignature();
    if (route === 'compass') aimCompass();
    if (route === 'catalog' && cat.hl) {
      const el = document.querySelector(`[data-tid="${cat.hl}"]`);
      if (el) { el.scrollIntoView({ block: 'center' }); setTimeout(() => FX.burstAt(el, { count: 24, colors: [FX.COLORS.lime, FX.COLORS.gold] }), 300); }
      cat.hl = null;
    }
    // «Шёпот» кузнеца: только в кузнице.
    FX.setWhisper(route === 'forge' || route === 'edit' ? whisperText : null);
    onScroll();
  }

  function whisperText() {
    if (!wiz || wiz.loading) return null;
    if (wiz.step === 1) return tr('whisper.start');
    const m = S.score(liveCard()).missing[0];
    return m ? tr('whisper.hint', m.label, m.gain, m.hint) : tr('whisper.done');
  }

  // Scroll-Driven Forge: прокрутка кузницы поднимает молот и раздувает жар.
  function onScroll() {
    const scene = $('#scene');
    if (!scene) return;
    const max = document.documentElement.scrollHeight - innerHeight;
    const p = max > 0 ? Math.min(1, scrollY / max) : 0;
    scene.style.setProperty('--scroll', p.toFixed(3));
  }
  addEventListener('scroll', onScroll, { passive: true });

  // ---------- Обработчики событий ----------
  app.addEventListener('click', e => {
    const a = e.target.closest('[data-role]');
    if (a) { st().role = a.dataset.role; Store.save(); }
    const btn = e.target.closest('[data-action]');
    if (!btn || btn.disabled) return;
    const id = btn.dataset.id;
    switch (btn.dataset.action) {
      case 'demo': window.Demo && window.Demo.run(); break;
      case 'sample': {
        const d = SEED.drafts.find(x => x.id === id);
        $('#w-draft').value = d.text; $('#w-company').value = d.company; $('#w-industry').value = d.industry;
        FX.play('paper');
        break;
      }
      case 'analyze': doAnalyze(); break;
      case 'restart': wiz = newWiz(); render(); break;
      case 'back1': wiz.step = 1; render(); break;
      case 'back2': wiz.step = 2; render(); break;
      case 'back3': wiz.step = 3; render(); break;
      case 'build': doBuild(); break;
      case 'refine': doRefine(); break;
      case 'confirm': doConfirm(); break;
      case 'publish': doPublish(); break;
      case 'publish-task': {
        FX.ritual(btn).then(() => {
          const t = Store.publish(id);
          toast(tr('toast.published', Store.catalogPosition(t.id), Store.published().length), 'ok');
          render();
          if (t.score >= 70) award('perfect-alloy');
        });
        break;
      }
      case 'view': cat.view = id; render(); break;
      case 'ind': cat.industry = id; render(); break;
      case 'lvl': cat.levels.has(id) ? cat.levels.delete(id) : cat.levels.add(id); render(); break;
      case 'sig-clear': { const c = $('#sig'); c.getContext('2d').clearRect(0, 0, c.width, c.height); sig = []; break; }
      case 'propose': doPropose(id); break;
      case 'unroll': {
        openScrolls.has(id) ? openScrolls.delete(id) : openScrolls.add(id);
        FX.play('paper');
        const el = document.querySelector(`[data-sid="${id}"]`);
        el.classList.toggle('open');
        el.querySelector('.toggle-label').textContent = tr(el.classList.contains('open') ? 'scroll.collapse' : 'scroll.expand');
        break;
      }
      case 'p-accept': decide(id, 'accepted'); break;
      case 'p-reject': decide(id, 'rejected'); break;
      case 'p-reset': Store.setProposalStatus(id, 'pending'); render(); break;
      case 'p-stage': {
        const stageId = $('#stage-' + id).value;
        const p = Store.confirmStage(id, stageId);
        if (p) { toast(tr('toast.stage', stageName(stageId), Store.team(p.teamId).name), 'ok'); render(); FX.burstAt(document.querySelector(`[data-sid="${id}"] .stages`), { count: 16 }); FX.play('spark'); }
        break;
      }
      case 'ai-save': {
        const s = st().settings;
        s.mode = $('#ai-mode').value;
        s.model = $('#ai-model').value.trim() || AI.DEFAULT_MODEL;
        s.apiKey = $('#ai-key').value.trim();
        s.xaiKey = $('#ai-xkey').value.trim();
        s.xaiModel = $('#ai-xmodel').value.trim() || 'grok-3-mini';
        Store.save();
        toast(s.mode !== 'local' && !s.apiKey && !s.xaiKey ? tr('toast.aiNoKey') : tr('toast.aiSaved'), 'ok');
        render(); break;
      }
      case 'reset-data':
        if (btn.dataset.armed) { Store.reset(); wiz = null; toast(tr('toast.reset'), 'ok'); location.hash = '#/'; render(); }
        else { btn.dataset.armed = '1'; btn.textContent = tr('ai.resetConfirm'); }
        break;
      case 'bad': runBadSample(+id); break;
    }
  });

  app.addEventListener('input', e => {
    const el = e.target;
    if (el.dataset.q !== undefined && wiz) {
      wiz.answers[el.dataset.q] = el.value;
      updateScene(el);
    }
    if (el.dataset.f && wiz && wiz.card) {
      wiz.card[el.dataset.f] = el.value;
      if (wiz.confirmedScore !== null) wiz.dirty = true;
      const sc = S.score(wiz.card);
      for (const f of S.SCORED) {
        const holder = document.getElementById('st-' + f.key);
        if (holder) holder.innerHTML = statusDot(sc.fields[f.key].status);
      }
      updateScene(el);
      const pub = app.querySelector('[data-action="publish"]');
      if (pub) pub.disabled = wiz.dirty || wiz.confirmedScore === null;
    }
    if (el.id === 'w-draft' && wiz) wiz.draft = el.value;
    if (el.id === 'w-company' && wiz) wiz.company = el.value;
    if (el.id === 'f-q') { cat.q = el.value; $('#catalog-body').innerHTML = catalogBody(); }
  });

  app.addEventListener('change', e => {
    const el = e.target;
    // Ответ закончен — удар молота.
    if (el.dataset.q !== undefined && el.value.trim()) { el.closest('.qcard').classList.add('hit'); strike(); }
    if (el.id === 'f-sort') { cat.sort = el.value; $('#catalog-body').innerHTML = catalogBody(); }
    if (el.id === 'w-industry' && wiz) wiz.industry = el.value;
    if (el.id === 'w-industry3' && wiz) {
      wiz.industry = el.value;
      if (wiz.confirmedScore !== null) wiz.dirty = true;
      const pub = app.querySelector('[data-action="publish"]');
      if (pub) pub.disabled = true;
    }
  });

  addEventListener('hashchange', () => FX.transition(() => { scrollTo(0, 0); render(); }));

  window.App = { render, drawDemoSignature, strike };
  Store.load();
  FX.loader();
  render();
})();
